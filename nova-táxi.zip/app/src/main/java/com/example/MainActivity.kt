package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.core.location.RealLocationManager
import com.example.ui.NovaViewModel
import com.example.ui.navigation.NovaNavGraph
import com.example.ui.theme.NovaTaxiTheme
import com.example.ui.theme.NovaWhite

class MainActivity : ComponentActivity() {
    private val viewModel: NovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val realLocationManager = remember { RealLocationManager(this) }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
                val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                if (fineGranted || coarseGranted) {
                    realLocationManager.startLocationUpdates { coords ->
                        viewModel.updateCurrentLocation(coords)
                    }
                }
            }

            LaunchedEffect(Unit) {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }

            NovaTaxiTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NovaWhite)
                ) {
                    NovaNavGraph(viewModel = viewModel)
                }
            }
        }
    }
}
