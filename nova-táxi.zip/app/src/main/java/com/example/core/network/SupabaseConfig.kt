package com.example.core.network

import com.example.BuildConfig

/**
 * Arquitetura de Integração com Supabase para NOVA Táxi.
 *
 * REGRA DE SEGURANÇA CRÍTICA:
 * - Apenas a 'anon_public_key' e 'supabase_url' são permitidas no cliente.
 * - 'service_role_key', passwords de base de dados e credenciais de infraestrutura
 *   NUNCA são embutidas no código nem no repositório.
 * - O Row Level Security (RLS) no Supabase garante que motoristas e passageiros
 *   só acedem aos dados permitidos pelos seus tokens JWT.
 */
object SupabaseConfig {
    const val OFFICIAL_PROJECT_REF = "rojyxfjaidyvtmsmefcf"
    const val DEFAULT_SUPABASE_URL = "https://rojyxfjaidyvtmsmefcf.supabase.co"
    const val DEFAULT_ANON_PUBLIC_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.anon_public_placeholder"

    private var runtimeUrl: String? = null
    private var runtimeAnonKey: String? = null

    val currentUrl: String
        get() {
            if (!runtimeUrl.isNullOrBlank()) return runtimeUrl!!
            return try {
                val field = BuildConfig::class.java.getField("SUPABASE_URL")
                val value = field.get(null) as? String
                if (!value.isNullOrBlank() && value.startsWith("http")) value else DEFAULT_SUPABASE_URL
            } catch (_: Exception) {
                DEFAULT_SUPABASE_URL
            }
        }

    val currentAnonKey: String
        get() {
            if (!runtimeAnonKey.isNullOrBlank()) return runtimeAnonKey!!
            return try {
                val field = BuildConfig::class.java.getField("SUPABASE_ANON_KEY")
                val value = field.get(null) as? String
                if (!value.isNullOrBlank() && value != "your_anon_public_key_here") value else DEFAULT_ANON_PUBLIC_KEY
            } catch (_: Exception) {
                DEFAULT_ANON_PUBLIC_KEY
            }
        }

    fun configure(url: String, anonKey: String) {
        if (url.isNotBlank()) runtimeUrl = url
        if (anonKey.isNotBlank()) runtimeAnonKey = anonKey
    }

    val isProductionConfigured: Boolean
        get() = currentAnonKey != DEFAULT_ANON_PUBLIC_KEY && currentAnonKey.length > 20
}
