package com.example.core.location

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import com.example.data.model.LocationPoint
import com.example.data.model.LuandaLocations
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

class PlacesSearchService(private val context: Context) {

    // Verified landmarks and zones in Luanda with real GPS coordinates
    private val verifiedLuandaPlaces = listOf(
        LocationPoint(
            id = "place_talatona_shop",
            name = "Shopping Avennida",
            address = "Via S8, Talatona, Luanda",
            latitude = -8.9168,
            longitude = 13.1843,
            shortcutType = "SHOPPING"
        ),
        LocationPoint(
            id = "place_belas_shop",
            name = "Belas Shopping",
            address = "Talatona Sul, Luanda",
            latitude = -8.9220,
            longitude = 13.1780,
            shortcutType = "SHOPPING"
        ),
        LocationPoint(
            id = "place_kero_talatona",
            name = "Hipermercado Kero Talatona",
            address = "Avenida Luanda Sul, Talatona",
            latitude = -8.9280,
            longitude = 13.1810,
            shortcutType = "SUPERMERCADO"
        ),
        LocationPoint(
            id = "place_kero_benfica",
            name = "Kero Benfica",
            address = "Estrada Principal do Benfica, Luanda",
            latitude = -8.9540,
            longitude = 13.1550,
            shortcutType = "SUPERMERCADO"
        ),
        LocationPoint(
            id = "place_aeroporto",
            name = "Aeroporto Internacional 4 de Fevereiro",
            address = "Avenida Deolinda Rodrigues, Luanda",
            latitude = -8.8584,
            longitude = 13.2312,
            shortcutType = "AEROPORTO"
        ),
        LocationPoint(
            id = "place_marginal",
            name = "Marginal de Luanda",
            address = "Avenida 4 de Fevereiro, Luanda",
            latitude = -8.8091,
            longitude = 13.2384,
            shortcutType = "PASSEIO"
        ),
        LocationPoint(
            id = "place_epic_sana",
            name = "Hotel Epic Sana Luanda",
            address = "Rua da Missão, Luanda",
            latitude = -8.8160,
            longitude = 13.2350,
            shortcutType = "HOTEL"
        ),
        LocationPoint(
            id = "place_hotel_presidente",
            name = "Hotel Presidente Luanda",
            address = "Largo 4 de Fevereiro, Baixa de Luanda",
            latitude = -8.8080,
            longitude = 13.2360,
            shortcutType = "HOTEL"
        ),
        LocationPoint(
            id = "place_kilamba_central",
            name = "Centralidade do Kilamba (Quarteirão K)",
            address = "Centralidade do Kilamba, Luanda Sul",
            latitude = -8.9950,
            longitude = 13.2560,
            shortcutType = "RESIDENCIAL"
        ),
        LocationPoint(
            id = "place_mutamba",
            name = "Largo da Mutamba",
            address = "Baixa de Luanda, Mutamba",
            latitude = -8.8145,
            longitude = 13.2340,
            shortcutType = "CENTRO"
        ),
        LocationPoint(
            id = "place_kinaxixi",
            name = "Largo do Kinaxixi",
            address = "Ingombota / Kinaxixi, Luanda",
            latitude = -8.8180,
            longitude = 13.2405,
            shortcutType = "CENTRO"
        ),
        LocationPoint(
            id = "place_ilha_cabo",
            name = "Ilha do Cabo (Ponto Final)",
            address = "Avenida Murtala Mohamed, Ilha de Luanda",
            latitude = -8.7690,
            longitude = 13.2450,
            shortcutType = "PRAIA"
        ),
        LocationPoint(
            id = "place_maianga",
            name = "Largo da Maianga",
            address = "Rua Amílcar Cabral, Maianga, Luanda",
            latitude = -8.8250,
            longitude = 13.2280,
            shortcutType = "CENTRO"
        ),
        LocationPoint(
            id = "place_viana_estrada",
            name = "Viana Centro / Estrada de Catete",
            address = "Viana, Luanda",
            latitude = -8.9020,
            longitude = 13.3720,
            shortcutType = "ZONA"
        ),
        LocationPoint(
            id = "place_morro_bento",
            name = "Morro Bento / Gamek",
            address = "Avenida 21 de Janeiro, Morro Bento, Luanda",
            latitude = -8.8780,
            longitude = 13.1950,
            shortcutType = "ZONA"
        ),
        LocationPoint(
            id = "place_alvalade",
            name = "Bairro Alvalade",
            address = "Avenida Comandante Gika, Alvalade, Luanda",
            latitude = -8.8350,
            longitude = 13.2320,
            shortcutType = "RESIDENCIAL"
        ),
        LocationPoint(
            id = "place_cazenga",
            name = "Cazenga / Marco Histórico",
            address = "Avenida Hoji-ya-Henda, Cazenga, Luanda",
            latitude = -8.8310,
            longitude = 13.2850,
            shortcutType = "ZONA"
        ),
        LocationPoint(
            id = "place_hospital_militar",
            name = "Hospital Militar Principal",
            address = "Rua Cirilo da Conceição, Luanda",
            latitude = -8.8220,
            longitude = 13.2370,
            shortcutType = "HOSPITAL"
        )
    )

    suspend fun searchPlaces(query: String, userLocation: LocationPoint? = null): List<LocationPoint> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        // 1. Filtragem inteligente nos pontos verificados de Luanda
        val localMatches = verifiedLuandaPlaces.filter { place ->
            place.name.contains(trimmed, ignoreCase = true) ||
            place.address.contains(trimmed, ignoreCase = true) ||
            (place.shortcutType != null && place.shortcutType.contains(trimmed, ignoreCase = true))
        }

        // 2. Geocoder oficial do Android (se disponível e online)
        val geocoderMatches = mutableListOf<LocationPoint>()
        try {
            if (Geocoder.isPresent()) {
                val geocoder = Geocoder(context, Locale("pt", "AO"))
                @Suppress("DEPRECATION")
                val results: List<Address>? = geocoder.getFromLocationName("$trimmed, Luanda, Angola", 5)
                results?.forEachIndexed { index, addr ->
                    val featureName = addr.featureName ?: addr.thoroughfare ?: trimmed
                    val addressLine = addr.getAddressLine(0) ?: "Luanda, Angola"
                    geocoderMatches.add(
                        LocationPoint(
                            id = "geo_${addr.latitude}_${addr.longitude}_$index",
                            name = featureName,
                            address = addressLine,
                            latitude = addr.latitude,
                            longitude = addr.longitude,
                            shortcutType = "GPS"
                        )
                    )
                }
            }
        } catch (_: Exception) {}

        // Combinar evitando duplicados próximos
        val combined = (localMatches + geocoderMatches).distinctBy {
            "${(it.latitude * 1000).roundToInt()}_${(it.longitude * 1000).roundToInt()}"
        }

        return@withContext combined
    }

    suspend fun reverseGeocode(latitude: Double, longitude: Double): LocationPoint = withContext(Dispatchers.IO) {
        // Encontrar o ponto mais próximo conhecido se estiver a menos de 200m
        val nearest = verifiedLuandaPlaces.minByOrNull {
            calculateDistanceKm(it.latitude, it.longitude, latitude, longitude)
        }
        if (nearest != null && calculateDistanceKm(nearest.latitude, nearest.longitude, latitude, longitude) < 0.25) {
            return@withContext nearest.copy(
                id = "map_sel_${System.currentTimeMillis()}",
                latitude = latitude,
                longitude = longitude
            )
        }

        try {
            if (Geocoder.isPresent()) {
                val geocoder = Geocoder(context, Locale("pt", "AO"))
                @Suppress("DEPRECATION")
                val results = geocoder.getFromLocation(latitude, longitude, 1)
                val first = results?.firstOrNull()
                if (first != null) {
                    val name = first.featureName ?: first.thoroughfare ?: "Local selecionado"
                    val address = first.getAddressLine(0) ?: "Luanda, Angola"
                    return@withContext LocationPoint(
                        id = "map_${latitude}_${longitude}",
                        name = name,
                        address = address,
                        latitude = latitude,
                        longitude = longitude,
                        shortcutType = "MAPA"
                    )
                }
            }
        } catch (_: Exception) {}

        return@withContext LocationPoint(
            id = "map_${latitude}_${longitude}",
            name = "Ponto no mapa (${String.format(Locale.US, "%.4f, %.4f", latitude, longitude)})",
            address = "Luanda, Angola",
            latitude = latitude,
            longitude = longitude,
            shortcutType = "MAPA"
        )
    }

    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val result = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, result)
        val distanceKm = result[0] / 1000.0
        return (distanceKm * 10.0).roundToInt() / 10.0
    }

    fun calculateDistanceKm(from: LocationPoint, to: LocationPoint): Double {
        return calculateDistanceKm(from.latitude, from.longitude, to.latitude, to.longitude)
    }
}
