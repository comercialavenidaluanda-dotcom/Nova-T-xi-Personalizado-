package com.example.core.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Coordinates(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 0f,
    val isRealGps: Boolean = false
)

class RealLocationManager(private val context: Context) {
    private val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)
    private val systemLocationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val _currentLocation = MutableStateFlow<Coordinates?>(null)
    val currentLocation: StateFlow<Coordinates?> = _currentLocation.asStateFlow()

    private var locationCallback: LocationCallback? = null

    @SuppressLint("MissingPermission")
    fun startLocationUpdates(
        intervalMs: Long = 5000L,
        onLocationUpdated: (Coordinates) -> Unit = {}
    ) {
        try {
            // First attempt with Google Play Services Fused Location
            val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMs)
                .setMinUpdateIntervalMillis(intervalMs / 2)
                .build()

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    val location = result.lastLocation ?: return
                    val coords = Coordinates(
                        latitude = location.latitude,
                        longitude = location.longitude,
                        accuracyMeters = location.accuracy,
                        isRealGps = true
                    )
                    _currentLocation.value = coords
                    onLocationUpdated(coords)
                }
            }

            fusedClient.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                Looper.getMainLooper()
            )

            // Also check last known location immediately
            fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
                if (loc != null) {
                    val coords = Coordinates(
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        accuracyMeters = loc.accuracy,
                        isRealGps = true
                    )
                    _currentLocation.value = coords
                    onLocationUpdated(coords)
                }
            }
        } catch (e: SecurityException) {
            // Fallback to system location provider if permission issue or fused provider unavailable
            trySystemLocationFallback(onLocationUpdated)
        } catch (e: Exception) {
            trySystemLocationFallback(onLocationUpdated)
        }
    }

    @SuppressLint("MissingPermission")
    private fun trySystemLocationFallback(onLocationUpdated: (Coordinates) -> Unit) {
        val mgr = systemLocationManager ?: return
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    val coords = Coordinates(
                        latitude = location.latitude,
                        longitude = location.longitude,
                        accuracyMeters = location.accuracy,
                        isRealGps = true
                    )
                    _currentLocation.value = coords
                    onLocationUpdated(coords)
                }
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }

            if (mgr.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 2f, listener, Looper.getMainLooper())
            } else if (mgr.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                mgr.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 2f, listener, Looper.getMainLooper())
            }
        } catch (_: Exception) {}
    }

    fun stopLocationUpdates() {
        locationCallback?.let {
            fusedClient.removeLocationUpdates(it)
        }
        locationCallback = null
    }
}
