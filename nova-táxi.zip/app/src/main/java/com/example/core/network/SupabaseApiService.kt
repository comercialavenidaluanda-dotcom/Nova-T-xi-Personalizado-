package com.example.core.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// Supabase Auth DTOs
@JsonClass(generateAdapter = true)
data class SupabaseSignUpPayload(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String,
    @Json(name = "phone") val phone: String? = null,
    @Json(name = "data") val data: Map<String, String> = emptyMap()
)

@JsonClass(generateAdapter = true)
data class SupabaseSignInPayload(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String
)

@JsonClass(generateAdapter = true)
data class SupabaseUser(
    @Json(name = "id") val id: String,
    @Json(name = "email") val email: String? = null,
    @Json(name = "phone") val phone: String? = null,
    @Json(name = "user_metadata") val userMetadata: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthSession(
    @Json(name = "access_token") val accessToken: String,
    @Json(name = "token_type") val tokenType: String = "bearer",
    @Json(name = "expires_in") val expiresIn: Long = 3600,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "user") val user: SupabaseUser
)

// PostgREST Database DTOs
@JsonClass(generateAdapter = true)
data class ProfileDto(
    @Json(name = "id") val id: String,
    @Json(name = "full_name") val fullName: String,
    @Json(name = "phone") val phone: String,
    @Json(name = "email") val email: String? = null,
    @Json(name = "role") val role: String, // "passenger" or "driver"
    @Json(name = "rating") val rating: Double = 5.0,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class DriverDto(
    @Json(name = "id") val id: String,
    @Json(name = "document_number") val documentNumber: String,
    @Json(name = "license_number") val licenseNumber: String,
    @Json(name = "is_online") val isOnline: Boolean = true,
    @Json(name = "is_verified") val isVerified: Boolean = true,
    @Json(name = "total_rides") val totalRides: Int = 0,
    @Json(name = "earnings_today_aoa") val earningsTodayAoa: Long = 0L
)

@JsonClass(generateAdapter = true)
data class VehicleDto(
    @Json(name = "id") val id: String? = null,
    @Json(name = "driver_id") val driverId: String,
    @Json(name = "brand") val brand: String,
    @Json(name = "model") val model: String,
    @Json(name = "license_plate") val licensePlate: String,
    @Json(name = "color") val color: String,
    @Json(name = "year") val year: Int,
    @Json(name = "category") val category: String,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class DriverLocationDto(
    @Json(name = "driver_id") val driverId: String,
    @Json(name = "latitude") val latitude: Double,
    @Json(name = "longitude") val longitude: Double,
    @Json(name = "heading") val heading: Float = 0f,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class RideRequestDto(
    @Json(name = "id") val id: String,
    @Json(name = "passenger_id") val passengerId: String,
    @Json(name = "passenger_name") val passengerName: String,
    @Json(name = "passenger_phone") val passengerPhone: String,
    @Json(name = "pickup_name") val pickupName: String,
    @Json(name = "pickup_lat") val pickupLat: Double,
    @Json(name = "pickup_lng") val pickupLng: Double,
    @Json(name = "dest_name") val destName: String,
    @Json(name = "dest_lat") val destLat: Double,
    @Json(name = "dest_lng") val destLng: Double,
    @Json(name = "category") val category: String,
    @Json(name = "estimated_price_aoa") val estimatedPriceAoa: Long,
    @Json(name = "distance_km") val distanceKm: Double,
    @Json(name = "payment_method") val paymentMethod: String,
    @Json(name = "status") val status: String,
    @Json(name = "driver_id") val driverId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class RideDto(
    @Json(name = "id") val id: String,
    @Json(name = "request_id") val requestId: String,
    @Json(name = "driver_id") val driverId: String,
    @Json(name = "passenger_id") val passengerId: String,
    @Json(name = "status") val status: String,
    @Json(name = "fare_amount_aoa") val fareAmountAoa: Long,
    @Json(name = "nova_commission_aoa") val novaCommissionAoa: Long, // 20%
    @Json(name = "driver_net_aoa") val driverNetAoa: Long, // 80%
    @Json(name = "payment_method") val paymentMethod: String = "CASH",
    @Json(name = "payment_status") val paymentStatus: String = "PENDING",
    @Json(name = "started_at") val startedAt: String? = null,
    @Json(name = "completed_at") val completedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class RideStatusHistoryDto(
    @Json(name = "id") val id: String? = null,
    @Json(name = "ride_id") val rideId: String,
    @Json(name = "status") val status: String,
    @Json(name = "changed_by") val changedBy: String? = null,
    @Json(name = "changed_at") val changedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PaymentDto(
    @Json(name = "id") val id: String,
    @Json(name = "ride_id") val rideId: String,
    @Json(name = "amount_aoa") val amountAoa: Long,
    @Json(name = "method") val method: String = "CASH",
    @Json(name = "status") val status: String = "COMPLETED",
    @Json(name = "recorded_at") val recordedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class CommissionDto(
    @Json(name = "id") val id: String? = null,
    @Json(name = "ride_id") val rideId: String,
    @Json(name = "total_fare_aoa") val totalFareAoa: Long,
    @Json(name = "nova_rate") val novaRate: Double = 0.20,
    @Json(name = "nova_amount_aoa") val novaAmountAoa: Long,
    @Json(name = "driver_amount_aoa") val driverAmountAoa: Long,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class RatingDto(
    @Json(name = "id") val id: String,
    @Json(name = "ride_id") val rideId: String,
    @Json(name = "from_user_id") val fromUserId: String,
    @Json(name = "to_user_id") val toUserId: String,
    @Json(name = "score") val score: Int,
    @Json(name = "comment") val comment: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class NotificationDto(
    @Json(name = "id") val id: String? = null,
    @Json(name = "user_id") val userId: String,
    @Json(name = "title") val title: String,
    @Json(name = "body") val body: String,
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null
)

// RPC Payloads & Responses
@JsonClass(generateAdapter = true)
data class NovaAcceptRidePayload(
    @Json(name = "p_request_id") val requestId: String,
    @Json(name = "p_driver_id") val driverId: String
)

@JsonClass(generateAdapter = true)
data class NovaAcceptRideResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "ride_id") val rideId: String? = null,
    @Json(name = "request_id") val requestId: String? = null,
    @Json(name = "status") val status: String? = null,
    @Json(name = "fare_amount_aoa") val fareAmountAoa: Long? = null,
    @Json(name = "nova_commission_aoa") val novaCommissionAoa: Long? = null,
    @Json(name = "driver_net_aoa") val driverNetAoa: Long? = null
)

@JsonClass(generateAdapter = true)
data class NovaUpdateStatusPayload(
    @Json(name = "p_ride_id") val rideId: String,
    @Json(name = "p_status") val status: String,
    @Json(name = "p_user_id") val userId: String
)

@JsonClass(generateAdapter = true)
data class NovaRecordPaymentPayload(
    @Json(name = "p_ride_id") val rideId: String,
    @Json(name = "p_amount_aoa") val amountAoa: Long
)

@JsonClass(generateAdapter = true)
data class NovaCalculateFarePayload(
    @Json(name = "p_category") val category: String,
    @Json(name = "p_distance_km") val distanceKm: Double
)

@JsonClass(generateAdapter = true)
data class NovaFareCalculationResponse(
    @Json(name = "category") val category: String = "COOL",
    @Json(name = "distance_km") val distanceKm: Double = 0.0,
    @Json(name = "fare_amount_aoa") val fareAmountAoa: Long = 0L,
    @Json(name = "nova_commission_aoa") val novaCommissionAoa: Long = 0L,
    @Json(name = "driver_net_aoa") val driverNetAoa: Long = 0L,
    @Json(name = "commission_rate") val commissionRate: Double = 0.20
)

// Retrofit API Definition
interface SupabaseAuthApi {
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Body payload: SupabaseSignUpPayload
    ): Response<SupabaseAuthSession>

    @POST("auth/v1/token?grant_type=password")
    suspend fun signIn(
        @Body payload: SupabaseSignInPayload
    ): Response<SupabaseAuthSession>
}

interface SupabaseRestApi {
    // Profiles
    @GET("rest/v1/profiles")
    suspend fun getProfile(
        @Query("id") idFilter: String, // "eq.uuid"
        @Query("select") select: String = "*"
    ): Response<List<ProfileDto>>

    @Headers("Prefer: return=representation")
    @POST("rest/v1/profiles")
    suspend fun insertProfile(
        @Body profile: ProfileDto
    ): Response<List<ProfileDto>>

    // Drivers
    @GET("rest/v1/drivers")
    suspend fun getDriver(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<DriverDto>>

    @Headers("Prefer: return=representation")
    @POST("rest/v1/drivers")
    suspend fun insertDriver(
        @Body driver: DriverDto
    ): Response<List<DriverDto>>

    @Headers("Prefer: return=representation")
    @PATCH("rest/v1/drivers")
    suspend fun updateDriverOnlineStatus(
        @Query("id") idFilter: String,
        @Body update: Map<String, Boolean>
    ): Response<List<DriverDto>>

    // Vehicles
    @GET("rest/v1/vehicles")
    suspend fun getVehicleForDriver(
        @Query("driver_id") driverFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<VehicleDto>>

    @Headers("Prefer: return=representation")
    @POST("rest/v1/vehicles")
    suspend fun insertVehicle(
        @Body vehicle: VehicleDto
    ): Response<List<VehicleDto>>

    // Live driver locations
    @GET("rest/v1/driver_locations")
    suspend fun getDriverLocations(
        @Query("select") select: String = "*"
    ): Response<List<DriverLocationDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/driver_locations")
    suspend fun upsertDriverLocation(
        @Body location: DriverLocationDto
    ): Response<Unit>

    // Ride Requests
    @Headers("Prefer: return=representation")
    @POST("rest/v1/ride_requests")
    suspend fun createRideRequest(
        @Body request: RideRequestDto
    ): Response<List<RideRequestDto>>

    @GET("rest/v1/ride_requests")
    suspend fun getRideRequest(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<RideRequestDto>>

    @GET("rest/v1/ride_requests")
    suspend fun getPendingRideRequests(
        @Query("status") statusFilter: String = "eq.REQUESTED",
        @Query("order") order: String = "created_at.desc",
        @Query("select") select: String = "*"
    ): Response<List<RideRequestDto>>

    @Headers("Prefer: return=representation")
    @PATCH("rest/v1/ride_requests")
    suspend fun updateRideRequestStatus(
        @Query("id") idFilter: String,
        @Body update: Map<String, String>
    ): Response<List<RideRequestDto>>

    // Rides
    @Headers("Prefer: return=representation")
    @POST("rest/v1/rides")
    suspend fun createRide(
        @Body ride: RideDto
    ): Response<List<RideDto>>

    @GET("rest/v1/rides")
    suspend fun getActiveRides(
        @Query("passenger_id") passengerFilter: String? = null,
        @Query("driver_id") driverFilter: String? = null,
        @Query("select") select: String = "*"
    ): Response<List<RideDto>>

    @GET("rest/v1/rides")
    suspend fun getRideById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<RideDto>>

    @GET("rest/v1/rides")
    suspend fun getRideByRequestId(
        @Query("request_id") reqFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<RideDto>>

    @Headers("Prefer: return=representation")
    @PATCH("rest/v1/rides")
    suspend fun updateRideStatus(
        @Query("id") idFilter: String,
        @Body update: Map<String, String>
    ): Response<List<RideDto>>

    // Payments (Real Cash)
    @Headers("Prefer: return=representation")
    @POST("rest/v1/payments")
    suspend fun recordPayment(
        @Body payment: PaymentDto
    ): Response<List<PaymentDto>>

    // Ratings
    @Headers("Prefer: return=representation")
    @POST("rest/v1/ratings")
    suspend fun recordRating(
        @Body rating: RatingDto
    ): Response<List<RatingDto>>

    // Notifications
    @GET("rest/v1/notifications")
    suspend fun getNotifications(
        @Query("user_id") userFilter: String,
        @Query("order") order: String = "created_at.desc"
    ): Response<List<NotificationDto>>

    // RPC Endpoints
    @POST("rest/v1/rpc/nova_accept_ride")
    suspend fun rpcAcceptRide(
        @Body payload: NovaAcceptRidePayload
    ): Response<NovaAcceptRideResponse>

    @POST("rest/v1/rpc/nova_update_ride_status")
    suspend fun rpcUpdateRideStatus(
        @Body payload: NovaUpdateStatusPayload
    ): Response<Map<String, Any>>

    @POST("rest/v1/rpc/nova_record_cash_payment")
    suspend fun rpcRecordCashPayment(
        @Body payload: NovaRecordPaymentPayload
    ): Response<Map<String, Any>>

    @POST("rest/v1/rpc/nova_calculate_fare_and_commission")
    suspend fun rpcCalculateFareAndCommission(
        @Body payload: NovaCalculateFarePayload
    ): Response<NovaFareCalculationResponse>
}

object SupabaseNetworkClient {
    private var currentToken: String? = null

    fun setAuthToken(token: String?) {
        currentToken = token
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        OkHttpClient.Builder()
            .addInterceptor { chain ->
                val requestBuilder = chain.request().newBuilder()
                    .addHeader("apikey", SupabaseConfig.currentAnonKey)
                    .addHeader("Content-Type", "application/json")

                val token = currentToken
                if (!token.isNullOrBlank()) {
                    requestBuilder.addHeader("Authorization", "Bearer $token")
                } else {
                    requestBuilder.addHeader("Authorization", "Bearer ${SupabaseConfig.currentAnonKey}")
                }

                chain.proceed(requestBuilder.build())
            }
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    val authApi: SupabaseAuthApi by lazy {
        Retrofit.Builder()
            .baseUrl(SupabaseConfig.currentUrl + "/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(SupabaseAuthApi::class.java)
    }

    val restApi: SupabaseRestApi by lazy {
        Retrofit.Builder()
            .baseUrl(SupabaseConfig.currentUrl + "/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(SupabaseRestApi::class.java)
    }
}
