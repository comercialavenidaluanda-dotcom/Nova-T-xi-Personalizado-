package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaLightCard
import com.example.core.designsystem.NovaSecondaryButton
import com.example.data.model.PaymentMethod
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    currentUser: User?,
    onSwitchRole: () -> Unit,
    onLogout: () -> Unit,
    onNavigateToHistory: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.MULTICAIXA_EXPRESS) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NovaIce)
            .statusBarsPadding()
            .testTag("profile_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Top title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "O Seu Perfil",
                    style = MaterialTheme.typography.headlineLarge,
                    color = NovaCharcoal,
                    fontWeight = FontWeight.Bold
                )
                NovaBadge(
                    text = if (currentUser?.role == UserRole.DRIVER) "MOTORISTA" else "PASSAGEIRO",
                    accentColor = if (currentUser?.role == UserRole.DRIVER) NovaLime else NovaOrange
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // User Info Header Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp, shape = RoundedCornerShape(24.dp), spotColor = NovaOrange.copy(alpha = 0.10f))
                    .clip(RoundedCornerShape(24.dp)),
                color = NovaWhite
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(NovaGradients.OrangeSun),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.name?.take(1) ?: "N",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Black,
                            color = NovaWhite
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentUser?.name ?: "Utilizador NOVA",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = NovaCharcoal
                        )
                        if (!currentUser?.phone.isNullOrBlank()) {
                            Text(
                                text = currentUser?.phone ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NovaTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = NovaSun, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "4.96 Avaliação",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = NovaCharcoal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Switch Profile Button
            NovaSecondaryButton(
                text = if (currentUser?.role == UserRole.DRIVER) "MUDAR PARA MODO PASSAGEIRO" else "MUDAR PARA MODO MOTORISTA",
                leadingIcon = Icons.Default.SwapHoriz,
                onClick = onSwitchRole,
                modifier = Modifier.fillMaxWidth(),
                testTag = "switch_role_profile_button"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Payment Methods Section (Cash, MCX, Referência, IBAN, KWiK)
            Text(
                text = "Métodos de Pagamento (Angola)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NovaCharcoal
            )
            Text(
                text = "Selecione o seu método padrão para corridas",
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            NovaLightCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    PaymentMethod.entries.forEachIndexed { index, method ->
                        val isSelected = selectedPaymentMethod == method
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) NovaOrange.copy(alpha = 0.08f) else Color.Transparent)
                                .clickable { selectedPaymentMethod = method }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("payment_option_${method.code}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) NovaOrange else NovaIce),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        tint = if (isSelected) NovaWhite else NovaTextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = method.label,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) NovaOrange else NovaCharcoal
                                    )
                                    Text(
                                        text = method.shortName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NovaTextSecondary
                                    )
                                }
                            }

                            if (isSelected) {
                                NovaBadge(text = "ATIVO", accentColor = NovaOrange)
                            }
                        }

                        if (index < PaymentMethod.entries.size - 1) {
                            HorizontalDivider(color = NovaBorderLight, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Menu Items
            Text(
                text = "Conta & Suporte",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NovaCharcoal
            )

            Spacer(modifier = Modifier.height(10.dp))

            NovaLightCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    ProfileMenuItem(
                        icon = Icons.Default.History,
                        title = "Histórico de Corridas",
                        onClick = onNavigateToHistory
                    )
                    HorizontalDivider(color = NovaBorderLight)
                    ProfileMenuItem(
                        icon = Icons.Default.Security,
                        title = "Segurança & Contactos de Emergência",
                        onClick = {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Centro de Segurança NOVA Luanda ativado 24/7.")
                            }
                        }
                    )
                    HorizontalDivider(color = NovaBorderLight)
                    ProfileMenuItem(
                        icon = Icons.Default.HelpOutline,
                        title = "Ajuda & Suporte ao Cliente",
                        onClick = {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Suporte NOVA disponível via WhatsApp e Linha de Apoio.")
                            }
                        }
                    )
                    HorizontalDivider(color = NovaBorderLight)
                    ProfileMenuItem(
                        icon = Icons.Default.Settings,
                        title = "Configurações da Aplicação",
                        onClick = {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Versão NOVA Táxi V1.0.0 Oficial.")
                            }
                        }
                    )
                    HorizontalDivider(color = NovaBorderLight)
                    ProfileMenuItem(
                        icon = Icons.Default.Logout,
                        title = "Terminar Sessão",
                        titleColor = NovaCoral,
                        iconTint = NovaCoral,
                        onClick = onLogout,
                        showChevron = false
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    titleColor: Color = NovaCharcoal,
    iconTint: Color = NovaOrange,
    showChevron: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = titleColor
            )
        }
        if (showChevron) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = NovaTextSecondary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
