package com.example.ui.passenger

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.BottomNavItem
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaBottomBar
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaPulseDot
import com.example.core.designsystem.NovaSecondaryButton
import com.example.core.location.Coordinates
import com.example.core.location.PlacesSearchService
import com.example.data.model.ActiveDriver
import com.example.data.model.LocationPoint
import com.example.data.model.LuandaLocations
import com.example.data.model.PaymentMethod
import com.example.data.model.RideCategory
import com.example.data.model.RideRequest
import com.example.data.model.RideStatus
import com.example.data.model.User
import com.example.ui.components.NovaMapCanvas
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RidesHistoryScreen
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaTextTertiary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

enum class BookingStep {
    ORIGIN_DESTINATION,
    CATEGORY_SELECTION,
    TRIP_SUMMARY,
    PAYMENT_SELECTION
}

@Composable
fun PassengerHomeScreen(
    currentUser: User?,
    nearbyDrivers: List<ActiveDriver>,
    activeRide: RideRequest?,
    rideHistory: List<RideRequest>,
    currentCoordinates: Coordinates? = null,
    onRequestRide: (pickup: LocationPoint, destination: LocationPoint, category: RideCategory, payment: PaymentMethod) -> Unit,
    onCancelRide: () -> Unit,
    onStepRideStatus: () -> Unit,
    onSubmitRating: (score: Int, comment: String) -> Unit,
    onSwitchToDriver: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val placesService = remember { PlacesSearchService(context) }
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val aoaFormatter = remember { NumberFormat.getNumberInstance(Locale.GERMANY) }

    var selectedTab by remember { mutableStateOf("home") }

    // Origem padrão atualizada pelo GPS real
    var pickup by remember {
        mutableStateOf(
            if (currentCoordinates != null && currentCoordinates.isRealGps) {
                LocationPoint(
                    id = "gps_current",
                    name = "Minha localização atual",
                    address = "Luanda, Angola",
                    latitude = currentCoordinates.latitude,
                    longitude = currentCoordinates.longitude
                )
            } else {
                LuandaLocations.MARGINAL
            }
        )
    }

    LaunchedEffect(currentCoordinates) {
        if (currentCoordinates != null && currentCoordinates.isRealGps) {
            pickup = LocationPoint(
                id = "gps_current",
                name = "Minha localização atual",
                address = "Luanda, Angola",
                latitude = currentCoordinates.latitude,
                longitude = currentCoordinates.longitude
            )
        }
    }

    // REGRA DE OURO: Destino inicial é estritamente NULL (sem auto-seleção ou mock inicial)
    var destination by remember { mutableStateOf<LocationPoint?>(null) }
    var selectedCategory by remember { mutableStateOf(RideCategory.ECONOMICA) }
    var selectedPayment by remember { mutableStateOf(PaymentMethod.CASH) }

    var bookingStep by remember { mutableStateOf(BookingStep.ORIGIN_DESTINATION) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var isChoosingOnMap by remember { mutableStateOf(false) }
    var mapCenterAddress by remember { mutableStateOf("Ponto selecionado em Luanda") }

    val estimatedDistanceKm = remember(pickup, destination) {
        val dest = destination
        if (dest != null) {
            placesService.calculateDistanceKm(pickup, dest)
        } else {
            0.0
        }
    }

    val estimatedPriceAoa = remember(selectedCategory, estimatedDistanceKm) {
        if (estimatedDistanceKm > 0) {
            val kmRate = when (selectedCategory) {
                RideCategory.ECONOMICA -> 110L
                RideCategory.COOL -> 150L
                RideCategory.EXECUTIVO -> 250L
                RideCategory.VIP -> 350L
                RideCategory.BIKE -> 90L
            }
            selectedCategory.basePriceAoa + (estimatedDistanceKm * kmRate).toLong()
        } else {
            selectedCategory.basePriceAoa
        }
    }

    val passengerNavItems = listOf(
        BottomNavItem("home", "Início", Icons.Default.Home),
        BottomNavItem("rides", "Viagens", Icons.Default.DirectionsCar),
        BottomNavItem("profile", "Perfil", Icons.Default.Person),
        BottomNavItem("help", "Ajuda", Icons.AutoMirrored.Filled.HelpOutline)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .testTag("passenger_root_container")
    ) {
        when (selectedTab) {
            "rides" -> {
                RidesHistoryScreen(
                    rides = rideHistory,
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            "profile" -> {
                ProfileScreen(
                    currentUser = currentUser,
                    onSwitchRole = onSwitchToDriver,
                    onLogout = onLogout,
                    onNavigateToHistory = { selectedTab = "rides" },
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            "help" -> {
                HelpScreen(
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            else -> {
                // "home" Tab
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 68.dp)
                ) {
                    // Mapa Interativo
                    NovaMapCanvas(
                        modifier = Modifier.fillMaxSize(),
                        pickupLocation = pickup,
                        destinationLocation = destination,
                        drivers = nearbyDrivers,
                        hasActiveRoute = activeRide != null || destination != null,
                        isChoosingOnMap = isChoosingOnMap,
                        chosenPointAddress = mapCenterAddress,
                        onConfirmMapPoint = {
                            coroutineScope.launch {
                                val mapLoc = placesService.reverseGeocode(-8.8350, 13.2320)
                                destination = mapLoc
                                isChoosingOnMap = false
                                bookingStep = BookingStep.CATEGORY_SELECTION
                            }
                        },
                        onCancelMapChoice = {
                            isChoosingOnMap = false
                        }
                    )

                    // Top Bar (Branca moderna com saudação e atalho de motorista)
                    if (!isChoosingOnMap) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .statusBarsPadding()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                                .shadow(12.dp, shape = RoundedCornerShape(22.dp), spotColor = NovaOrange.copy(alpha = 0.12f)),
                            shape = RoundedCornerShape(22.dp),
                            color = NovaWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "NOVA TÁXI",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Black,
                                            color = NovaOrange,
                                            letterSpacing = 1.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        NovaPulseDot(color = NovaLime, size = 6.dp)
                                    }
                                    Text(
                                        text = "Olá ${currentUser?.name?.substringBefore(" ") ?: "👋"}, para onde vamos?",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = NovaCharcoal
                                    )
                                }

                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { onSwitchToDriver() }
                                        .border(1.dp, NovaBorder, RoundedCornerShape(14.dp)),
                                    color = NovaIce
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DirectionsCar,
                                            contentDescription = null,
                                            tint = NovaOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Motorista",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = NovaCharcoal
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Floating Bottom Booking Flow
                    if (!isChoosingOnMap) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            if (activeRide == null) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .shadow(20.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaCharcoal.copy(alpha = 0.12f))
                                        .clip(RoundedCornerShape(26.dp)),
                                    color = NovaWhite,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(18.dp)
                                    ) {
                                        when (bookingStep) {
                                            BookingStep.ORIGIN_DESTINATION -> {
                                                // PASSO 1 & 2: ORIGEM E DESTINO
                                                NovaBadge(text = "PASSO 1 DE 6 • ORIGEM & DESTINO", accentColor = NovaOrange)
                                                Spacer(modifier = Modifier.height(10.dp))

                                                // Pickup Field
                                                Surface(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = NovaIce,
                                                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaLime))
                                                        Spacer(modifier = Modifier.width(10.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = "Partida",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = NovaTextSecondary,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                            Text(
                                                                text = pickup.name,
                                                                style = MaterialTheme.typography.bodyMedium,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = NovaCharcoal,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                // Destination Trigger (CAMPO INICIALMENTE VAZIO)
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(14.dp))
                                                        .clickable { showSearchDialog = true }
                                                        .border(
                                                            width = if (destination != null) 2.dp else 1.dp,
                                                            color = if (destination != null) NovaOrange else NovaBorder,
                                                            shape = RoundedCornerShape(14.dp)
                                                        )
                                                        .testTag("destination_field"),
                                                    color = NovaWhite
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = "📍", fontSize = 20.sp)
                                                        Spacer(modifier = Modifier.width(10.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = "Destino",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = NovaTextSecondary,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                            Text(
                                                                text = destination?.name ?: "Para onde vamos hoje?",
                                                                style = MaterialTheme.typography.bodyLarge,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (destination != null) NovaCharcoal else NovaTextTertiary,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                        }
                                                        Icon(
                                                            imageVector = Icons.Default.Search,
                                                            contentDescription = "Pesquisar",
                                                            tint = NovaOrange,
                                                            modifier = Modifier.size(22.dp)
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(14.dp))

                                                // Botão de Pesquisa / Avanço
                                                if (destination == null) {
                                                    NovaGradientButton(
                                                        text = "PESQUISAR DESTINO 🔎",
                                                        brush = NovaGradients.OrangeSun,
                                                        onClick = {
                                                            // NÃO seleciona destino automaticamente — apenas abre a tela de pesquisa!
                                                            showSearchDialog = true
                                                        },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag("button_search_destination")
                                                    )
                                                } else {
                                                    NovaGradientButton(
                                                        text = "CONFIRMAR DESTINO & ESCOLHER CATEGORIA →",
                                                        brush = NovaGradients.OrangeSun,
                                                        onClick = {
                                                            bookingStep = BookingStep.CATEGORY_SELECTION
                                                        },
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                }
                                            }

                                            BookingStep.CATEGORY_SELECTION -> {
                                                // PASSO 3: ESCOLHA DO SERVIÇO (5 CATEGORIAS COMPLETAS)
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    NovaBadge(text = "PASSO 3 DE 6 • CATEGORIA", accentColor = NovaSun)
                                                    Text(
                                                        text = "Mudar destino",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = NovaOrange,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.clickable {
                                                            bookingStep = BookingStep.ORIGIN_DESTINATION
                                                        }
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(10.dp))

                                                Text(
                                                    text = "Escolha o Serviço",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NovaCharcoal
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))

                                                // 5 Categorias em Lista Horizontal com Ícones e Preços
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    RideCategory.entries.forEach { cat ->
                                                        val isSelected = selectedCategory == cat
                                                        CategoryLightCard(
                                                            category = cat,
                                                            isSelected = isSelected,
                                                            formattedPrice = "${aoaFormatter.format(cat.basePriceAoa)} Kz",
                                                            onClick = { selectedCategory = cat }
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    NovaSecondaryButton(
                                                        text = "← VOLTAR",
                                                        onClick = { bookingStep = BookingStep.ORIGIN_DESTINATION },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    NovaGradientButton(
                                                        text = "RESUMO DA VIAGEM →",
                                                        brush = NovaGradients.OrangeSun,
                                                        onClick = { bookingStep = BookingStep.TRIP_SUMMARY },
                                                        modifier = Modifier.weight(1.8f)
                                                    )
                                                }
                                            }

                                            BookingStep.TRIP_SUMMARY -> {
                                                // PASSO 4: RESUMO DA CORRIDA
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    NovaBadge(text = "PASSO 4 DE 6 • RESUMO", accentColor = NovaPurple)
                                                    Text(
                                                        text = "${aoaFormatter.format(estimatedPriceAoa)} Kz",
                                                        style = MaterialTheme.typography.titleLarge,
                                                        fontWeight = FontWeight.Black,
                                                        color = NovaOrange
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(12.dp))

                                                Surface(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = NovaIce,
                                                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaLime))
                                                            Spacer(modifier = Modifier.width(8.dp))
                                                            Text(
                                                                text = "Partida: ${pickup.name}",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = NovaCharcoal,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                        }
                                                        Spacer(modifier = Modifier.height(6.dp))
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaOrange))
                                                            Spacer(modifier = Modifier.width(8.dp))
                                                            Text(
                                                                text = "Destino: ${destination?.name}",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = NovaCharcoal,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                        }
                                                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = NovaBorderLight)
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text(
                                                                text = "Distância: $estimatedDistanceKm km",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = NovaTextSecondary
                                                            )
                                                            Text(
                                                                text = "Categoria: ${selectedCategory.title}",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = selectedCategory.accentColor
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    NovaSecondaryButton(
                                                        text = "← VOLTAR",
                                                        onClick = { bookingStep = BookingStep.CATEGORY_SELECTION },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    NovaGradientButton(
                                                        text = "ESCOLHER PAGAMENTO →",
                                                        brush = NovaGradients.OrangeSun,
                                                        onClick = { bookingStep = BookingStep.PAYMENT_SELECTION },
                                                        modifier = Modifier.weight(1.8f)
                                                    )
                                                }
                                            }

                                            BookingStep.PAYMENT_SELECTION -> {
                                                // PASSO 5 & 6: FORMA DE PAGAMENTO E CONFIRMAÇÃO
                                                NovaBadge(text = "PASSO 5 & 6 • PAGAMENTO & CONFIRMAÇÃO", accentColor = NovaLime)
                                                Spacer(modifier = Modifier.height(10.dp))

                                                Text(
                                                    text = "Como deseja pagar a viagem?",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NovaCharcoal
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))

                                                // Payment Method 1: CASH (Produção)
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .clickable { selectedPayment = PaymentMethod.CASH }
                                                        .border(
                                                            width = if (selectedPayment == PaymentMethod.CASH) 2.dp else 1.dp,
                                                            color = if (selectedPayment == PaymentMethod.CASH) NovaLime else NovaBorder,
                                                            shape = RoundedCornerShape(12.dp)
                                                        ),
                                                    color = if (selectedPayment == PaymentMethod.CASH) NovaLime.copy(alpha = 0.08f) else NovaIce
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = "💵", fontSize = 20.sp)
                                                        Spacer(modifier = Modifier.width(12.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = "Dinheiro em Mãos (Cash)",
                                                                style = MaterialTheme.typography.titleMedium,
                                                                fontWeight = FontWeight.Bold,
                                                                color = NovaCharcoal
                                                            )
                                                            Text(
                                                                text = "Pague diretamente ao motorista no final da viagem",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = NovaTextSecondary
                                                            )
                                                        }
                                                        if (selectedPayment == PaymentMethod.CASH) {
                                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NovaLime, modifier = Modifier.size(20.dp))
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                // Payment Method 2: MCX (Em Homologação)
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .border(1.dp, NovaBorderLight, RoundedCornerShape(12.dp)),
                                                    color = NovaIce.copy(alpha = 0.6f)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = "📱", fontSize = 20.sp)
                                                        Spacer(modifier = Modifier.width(12.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = "Multicaixa Express (MCX)",
                                                                style = MaterialTheme.typography.titleMedium,
                                                                fontWeight = FontWeight.Bold,
                                                                color = NovaTextSecondary
                                                            )
                                                            Text(
                                                                text = "Em homologação bancária",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = NovaTextTertiary
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))

                                                // Botão Final de Confirmação da Corrida
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    NovaSecondaryButton(
                                                        text = "← VOLTAR",
                                                        onClick = { bookingStep = BookingStep.TRIP_SUMMARY },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    NovaGradientButton(
                                                        text = "CONFIRMAR VIAGEM • ${aoaFormatter.format(estimatedPriceAoa)} Kz",
                                                        brush = NovaGradients.OrangeSun,
                                                        onClick = {
                                                            val dest = destination
                                                            if (dest != null) {
                                                                onRequestRide(pickup, dest, selectedCategory, selectedPayment)
                                                                bookingStep = BookingStep.ORIGIN_DESTINATION
                                                            }
                                                        },
                                                        modifier = Modifier
                                                            .weight(2f)
                                                            .testTag("button_pedir_corrida")
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                // TELA DE CORRIDA ATIVA COM ESTADOS REAIS DO SUPABASE
                                ActiveRideFlowSheet(
                                    ride = activeRide,
                                    aoaFormatter = aoaFormatter,
                                    onCancel = onCancelRide,
                                    onStepNext = onStepRideStatus,
                                    onSubmitRating = onSubmitRating
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Navigation Bar (4 Menus Limpos)
        if (!isChoosingOnMap) {
            NovaBottomBar(
                items = passengerNavItems,
                selectedId = selectedTab,
                onItemSelected = { selectedTab = it },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // Search Dialog com Autocomplete e SEM Auto-seleção
        if (showSearchDialog) {
            DestinationSearchDialog(
                pickupLocation = pickup,
                recentDestinations = rideHistory.map { it.destination }.distinctBy { it.id }.take(4),
                onDestinationConfirmed = { loc ->
                    destination = loc
                    showSearchDialog = false
                    bookingStep = BookingStep.CATEGORY_SELECTION
                },
                onChooseOnMapClick = {
                    showSearchDialog = false
                    isChoosingOnMap = true
                },
                onDismiss = {
                    showSearchDialog = false
                }
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(16.dp)
        )
    }
}

@Composable
private fun CategoryLightCard(
    category: RideCategory,
    isSelected: Boolean,
    formattedPrice: String,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) category.accentColor else NovaBorderLight

    Surface(
        modifier = Modifier
            .width(136.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("category_${category.name.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) category.accentColor.copy(alpha = 0.08f) else NovaWhite
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(category.accentColor.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (category) {
                            RideCategory.ECONOMICA -> Icons.Default.DirectionsCar
                            RideCategory.COOL -> Icons.Default.DirectionsCar
                            RideCategory.EXECUTIVO -> Icons.Default.WorkspacePremium
                            RideCategory.VIP -> Icons.Default.ElectricCar
                            RideCategory.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                        },
                        contentDescription = null,
                        tint = category.accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Text(
                    text = "${category.estimatedMinutes} min",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = NovaTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = category.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = NovaCharcoal
            )
            Text(
                text = formattedPrice,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = category.accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = category.capacity,
                style = MaterialTheme.typography.labelSmall,
                color = NovaTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ActiveRideFlowSheet(
    ride: RideRequest,
    aoaFormatter: NumberFormat,
    onCancel: () -> Unit,
    onStepNext: () -> Unit,
    onSubmitRating: (Int, String) -> Unit
) {
    var ratingScore by remember { mutableStateOf(5) }
    var ratingComment by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(24.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaOrange.copy(alpha = 0.20f))
            .clip(RoundedCornerShape(26.dp)),
        color = NovaWhite,
        border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header: Status Badge & Pulse
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    NovaBadge(
                        text = "ETAPA ${ride.status.stepIndex}/6 • ${ride.status.displayTitle.uppercase()}",
                        accentColor = when (ride.status) {
                            RideStatus.REQUESTED, RideStatus.SEARCHING -> NovaSun
                            RideStatus.ACCEPTED -> NovaOrange
                            RideStatus.ARRIVED, RideStatus.IN_PROGRESS -> NovaLime
                            RideStatus.COMPLETED -> NovaPurple
                            RideStatus.CANCELLED -> NovaCoral
                        }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ride.status.description,
                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 18.sp),
                        fontWeight = FontWeight.Bold,
                        color = NovaCharcoal
                    )
                }

                if (ride.status == RideStatus.SEARCHING || ride.status == RideStatus.REQUESTED) {
                    NovaPulseDot(color = NovaOrange, size = 12.dp)
                } else if (ride.status == RideStatus.IN_PROGRESS) {
                    NovaPulseDot(color = NovaLime, size = 12.dp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Rating Step (When COMPLETED)
            if (ride.status == RideStatus.COMPLETED) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(NovaIce)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Viagem Concluída • Pagamento em Dinheiro (Cash)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NovaCharcoal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Total Pago: ${aoaFormatter.format(ride.priceAoa)} Kz",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = NovaOrange
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Como foi a sua experiência com a NOVA?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NovaTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..5).forEach { star ->
                            IconButton(onClick = { ratingScore = star }) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "$star estrelas",
                                    tint = if (star <= ratingScore) NovaSun else NovaBorder,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    NovaGradientButton(
                        text = "ENVIAR AVALIAÇÃO",
                        brush = NovaGradients.OrangeSun,
                        onClick = { onSubmitRating(ratingScore, ratingComment) },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "submit_rating_btn"
                    )
                }
            } else {
                // Driver Information Card (When Assigned or Beyond)
                if (ride.driver != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = NovaIce,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(NovaOrange),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ride.driver.name.take(1),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = NovaWhite
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ride.driver.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaCharcoal
                                )
                                Text(
                                    text = "${ride.driver.vehicleModel} • ${ride.driver.vehiclePlate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NovaTextSecondary
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = NovaSun, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${ride.driver.rating}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = NovaCharcoal
                                    )
                                }
                            }

                            // Phone Call Action
                            IconButton(
                                onClick = {},
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(NovaLime.copy(alpha = 0.15f))
                            ) {
                                Icon(Icons.Default.Call, contentDescription = "Ligar", tint = NovaLime)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Origin & Destination Info
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = NovaIce,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaLime))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "De: ${ride.pickup.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = NovaCharcoal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaOrange))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Para: ${ride.destination.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = NovaCharcoal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Actions: Cancel or Step to Next Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    NovaSecondaryButton(
                        text = "CANCELAR",
                        onClick = onCancel,
                        modifier = Modifier.weight(1f)
                    )

                    NovaGradientButton(
                        text = when (ride.status) {
                            RideStatus.REQUESTED, RideStatus.SEARCHING -> "A PROCURAR..."
                            RideStatus.ACCEPTED -> "MOTORISTA A CAMINHO"
                            RideStatus.ARRIVED -> "MOTORISTA CHEGOU"
                            RideStatus.IN_PROGRESS -> "EM VIAGEM"
                            RideStatus.COMPLETED -> "AVALIAR EXPERIÊNCIA"
                            else -> "CONCLUIR"
                        },
                        brush = when (ride.status) {
                            RideStatus.IN_PROGRESS -> NovaGradients.SunLime
                            RideStatus.COMPLETED -> NovaGradients.OrangeCoral
                            else -> NovaGradients.OrangeSun
                        },
                        onClick = onStepNext,
                        modifier = Modifier.weight(1.5f),
                        testTag = "step_ride_flow_button"
                    )
                }
            }
        }
    }
}
