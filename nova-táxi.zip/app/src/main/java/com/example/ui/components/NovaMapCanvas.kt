package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaSecondaryButton
import com.example.data.model.ActiveDriver
import com.example.data.model.LocationPoint
import com.example.data.model.RideCategory
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaWhite

@Composable
fun NovaMapCanvas(
    modifier: Modifier = Modifier,
    pickupLocation: LocationPoint?,
    destinationLocation: LocationPoint?,
    drivers: List<ActiveDriver>,
    hasActiveRoute: Boolean = false,
    isChoosingOnMap: Boolean = false,
    chosenPointAddress: String? = null,
    onConfirmMapPoint: (() -> Unit)? = null,
    onCancelMapChoice: (() -> Unit)? = null,
    onRecenterClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_radar")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 14f,
        targetValue = 64f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_radius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Crisp Light Map Base (Off-white / pale stone)
            drawRect(color = Color(0xFFF8FAFC))

            // 2. City Blocks & Green Parks
            drawRoundRect(
                color = Color(0xFFE8F5E9),
                topLeft = Offset(width * 0.52f, height * 0.18f),
                size = Size(width * 0.38f, height * 0.14f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f, 20f)
            )
            drawRoundRect(
                color = Color(0xFFE8F5E9),
                topLeft = Offset(width * 0.10f, height * 0.62f),
                size = Size(width * 0.30f, height * 0.16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f, 24f)
            )

            // Ilha do Cabo & Baía de Luanda Waterfront (Soft Blue Tint)
            val coastlinePath = Path().apply {
                moveTo(width * 0.75f, 0f)
                cubicTo(
                    width * 0.68f, height * 0.12f,
                    width * 0.58f, height * 0.22f,
                    width * 0.62f, height * 0.38f
                )
                cubicTo(
                    width * 0.65f, height * 0.48f,
                    width * 0.85f, height * 0.60f,
                    width, height * 0.72f
                )
                lineTo(width, 0f)
                close()
            }
            drawPath(
                path = coastlinePath,
                color = Color(0xFFE0F2FE)
            )

            // 3. Arterial Roads & Avenues in Luanda
            val roadColor = Color(0xFFFFFFFF)
            val roadBorderColor = Color(0xFFE2E8F0)

            // Avenida 4 de Fevereiro (Marginal)
            drawRoad(
                start = Offset(width * 0.62f, 0f),
                end = Offset(width * 0.55f, height * 0.45f),
                roadColor = roadColor,
                borderColor = roadBorderColor,
                widthPx = 28f
            )

            // Avenida Deolinda Rodrigues / Estrada de Catete
            drawRoad(
                start = Offset(0f, height * 0.38f),
                end = Offset(width, height * 0.46f),
                roadColor = roadColor,
                borderColor = roadBorderColor,
                widthPx = 32f
            )

            // Via Expressa / Estrada da Samba / Talatona S8
            drawRoad(
                start = Offset(width * 0.25f, height),
                end = Offset(width * 0.78f, height * 0.25f),
                roadColor = roadColor,
                borderColor = roadBorderColor,
                widthPx = 26f
            )

            // Secondary Connecting Streets
            drawRoad(
                start = Offset(width * 0.15f, height * 0.15f),
                end = Offset(width * 0.85f, height * 0.85f),
                roadColor = roadColor,
                borderColor = roadBorderColor,
                widthPx = 18f
            )

            // 4. Passenger Pickup Position & Pulse Radar
            val userPos = Offset(width * 0.35f, height * 0.42f)

            // Radar pulse animation
            drawCircle(
                color = NovaOrange.copy(alpha = pulseAlpha),
                radius = pulseRadius,
                center = userPos
            )
            // Outer white halo
            drawCircle(
                color = NovaWhite,
                radius = 16f,
                center = userPos
            )
            // Orange active core
            drawCircle(
                brush = Brush.linearGradient(listOf(NovaOrange, NovaSun)),
                radius = 8f,
                center = userPos
            )

            // 5. Destination Pin & Glowing Route Path
            val destPos = Offset(width * 0.74f, height * 0.68f)

            if (destinationLocation != null || hasActiveRoute) {
                val routePath = Path().apply {
                    moveTo(userPos.x, userPos.y)
                    cubicTo(
                        width * 0.48f, height * 0.50f,
                        width * 0.60f, height * 0.56f,
                        destPos.x, destPos.y
                    )
                }

                // Warm outer shadow for depth
                drawPath(
                    path = routePath,
                    color = NovaOrange.copy(alpha = 0.25f),
                    style = Stroke(width = 16f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                // Crisp vibrant orange gradient route
                drawPath(
                    path = routePath,
                    brush = Brush.linearGradient(listOf(NovaOrange, NovaCoral)),
                    style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                // Destination Pin Marker
                drawCircle(
                    color = NovaCoral.copy(alpha = 0.25f),
                    radius = 22f,
                    center = destPos
                )
                drawCircle(
                    color = NovaWhite,
                    radius = 12f,
                    center = destPos
                )
                drawCircle(
                    color = NovaCoral,
                    radius = 8f,
                    center = destPos
                )
            }

            // 6. Nearby Drivers on Map
            val driverOffsets = listOf(
                Offset(width * 0.28f, height * 0.36f) to 45f,
                Offset(width * 0.46f, height * 0.30f) to 120f,
                Offset(width * 0.42f, height * 0.58f) to -30f,
                Offset(width * 0.20f, height * 0.52f) to 80f,
                Offset(width * 0.64f, height * 0.40f) to 210f
            )

            val displayDrivers = if (drivers.isNotEmpty()) drivers else listOf(
                ActiveDriver("d1", "M1", "", 4.9, 10, "Car", "P", "C", 0.0, 0.0, 45f, RideCategory.COOL),
                ActiveDriver("d2", "M2", "", 4.9, 10, "Car", "P", "C", 0.0, 0.0, 120f, RideCategory.ECONOMICA),
                ActiveDriver("d3", "M3", "", 4.9, 10, "Car", "P", "C", 0.0, 0.0, -30f, RideCategory.EXECUTIVO)
            )

            displayDrivers.take(driverOffsets.size).forEachIndexed { index, driver ->
                val (pos, heading) = driverOffsets[index]
                drawLightDriverVehicle(pos, heading, driver.category.accentColor)
            }
        }

        // Center Pin when in "Escolher no mapa" mode
        if (isChoosingOnMap) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 120.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NovaCharcoal,
                        shadowElevation = 8.dp
                    ) {
                        Text(
                            text = "Mova o mapa para apontar o destino",
                            style = MaterialTheme.typography.labelSmall,
                            color = NovaWhite,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Pino Central",
                        tint = NovaOrange,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            // Bottom Confirmation Bar for "Escolher no mapa"
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .shadow(16.dp, shape = RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                color = NovaWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    NovaBadge(text = "DESTINO NO MAPA", accentColor = NovaOrange)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = chosenPointAddress ?: "Ponto selecionado em Luanda",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NovaCharcoal
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NovaSecondaryButton(
                            text = "CANCELAR",
                            onClick = { onCancelMapChoice?.invoke() },
                            modifier = Modifier.weight(1f)
                        )
                        NovaGradientButton(
                            text = "CONFIRMAR ESTE LOCAL",
                            brush = NovaGradients.OrangeSun,
                            onClick = { onConfirmMapPoint?.invoke() },
                            modifier = Modifier.weight(1.8f),
                            testTag = "confirm_map_point_btn"
                        )
                    }
                }
            }
        }

        // Top Status Overlay: "Luanda • Trânsito Fluido"
        if (!isChoosingOnMap) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .shadow(8.dp, shape = RoundedCornerShape(20.dp), spotColor = NovaOrange.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(20.dp),
                color = NovaWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NovaLime)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Luanda • Trânsito Fluido",
                        style = MaterialTheme.typography.labelSmall,
                        color = NovaCharcoal,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Floating Recenter GPS Action Button
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .shadow(10.dp, shape = CircleShape, spotColor = NovaOrange.copy(alpha = 0.2f))
                        .clickable { onRecenterClick() }
                        .testTag("map_recenter_button"),
                    shape = CircleShape,
                    color = NovaWhite,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorder)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.GpsFixed,
                            contentDescription = "Recentrar GPS",
                            tint = NovaOrange,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawRoad(
    start: Offset,
    end: Offset,
    roadColor: Color,
    borderColor: Color,
    widthPx: Float
) {
    drawLine(
        color = borderColor,
        start = start,
        end = end,
        strokeWidth = widthPx + 3f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = roadColor,
        start = start,
        end = end,
        strokeWidth = widthPx,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawLightDriverVehicle(
    center: Offset,
    heading: Float,
    accentColor: Color
) {
    drawCircle(
        color = Color(0x22000000),
        radius = 16f,
        center = Offset(center.x, center.y + 2f)
    )

    rotate(degrees = heading, pivot = center) {
        val carWidth = 18f
        val carHeight = 32f

        drawRoundRect(
            color = NovaWhite,
            topLeft = Offset(center.x - carWidth / 2, center.y - carHeight / 2),
            size = Size(carWidth, carHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )
        drawRoundRect(
            color = accentColor,
            topLeft = Offset(center.x - (carWidth - 3f) / 2, center.y - (carHeight - 3f) / 2),
            size = Size(carWidth - 3f, carHeight - 3f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f, 5f)
        )
        drawRoundRect(
            color = NovaCharcoal,
            topLeft = Offset(center.x - 5f, center.y - 7f),
            size = Size(10f, 6f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
        )
        drawCircle(
            color = NovaSun,
            radius = 2.5f,
            center = Offset(center.x - 5f, center.y - carHeight / 2 + 1f)
        )
        drawCircle(
            color = NovaSun,
            radius = 2.5f,
            center = Offset(center.x + 5f, center.y - carHeight / 2 + 1f)
        )
    }
}
