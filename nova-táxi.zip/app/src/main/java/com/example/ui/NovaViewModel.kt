package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.location.Coordinates
import com.example.data.model.ActiveDriver
import com.example.data.model.LocationPoint
import com.example.data.model.PaymentMethod
import com.example.data.model.RideCategory
import com.example.data.model.RideRequest
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.data.repository.AuthRepository
import com.example.data.repository.RealSupabaseAuthRepository
import com.example.data.repository.RealSupabaseRideRepository
import com.example.data.repository.RideRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NovaViewModel(
    val authRepository: AuthRepository = RealSupabaseAuthRepository(),
    val rideRepository: RideRepository = RealSupabaseRideRepository()
) : ViewModel() {

    val currentUser: StateFlow<User?> = authRepository.currentUser
    val activeRide: StateFlow<RideRequest?> = rideRepository.activeRide
    val nearbyDrivers: StateFlow<List<ActiveDriver>> = rideRepository.nearbyDrivers
    val incomingDriverRequest: StateFlow<RideRequest?> = rideRepository.incomingDriverRequest
    val rideHistory: StateFlow<List<RideRequest>> = rideRepository.rideHistory

    private val _currentLocation = MutableStateFlow<Coordinates?>(null)
    val currentLocation: StateFlow<Coordinates?> = _currentLocation.asStateFlow()

    fun updateCurrentLocation(coords: Coordinates) {
        _currentLocation.value = coords
        // Sincronizar localização real por GPS com o Supabase quando motorista estiver online
        val user = currentUser.value
        if (user != null && user.role == UserRole.DRIVER && user.driverProfile?.isOnline == true) {
            viewModelScope.launch {
                rideRepository.updateDriverGpsLocation(
                    driverId = user.id,
                    lat = coords.latitude,
                    lng = coords.longitude,
                    heading = 0f
                )
            }
        }
    }

    fun login(identifier: String, pass: String, onResult: (Result<UserRole>) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.login(identifier, pass)
            result.onSuccess { user ->
                onResult(Result.success(user.role))
            }.onFailure { error ->
                onResult(Result.failure(error))
            }
        }
    }

    fun registerPassenger(
        name: String,
        phone: String,
        email: String?,
        password: String,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.registerPassenger(name, phone, email, password)
            result.onSuccess {
                onResult(Result.success(Unit))
            }.onFailure {
                onResult(Result.failure(it))
            }
        }
    }

    fun registerDriver(
        name: String,
        phone: String,
        email: String,
        password: String,
        documentNumber: String,
        licenseNumber: String,
        vehicleBrand: String,
        vehicleModel: String,
        licensePlate: String,
        vehicleColor: String,
        vehicleYear: Int,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.registerDriver(
                name, phone, email, password,
                documentNumber, licenseNumber,
                vehicleBrand, vehicleModel,
                licensePlate, vehicleColor, vehicleYear
            )
            result.onSuccess {
                onResult(Result.success(Unit))
            }.onFailure {
                onResult(Result.failure(it))
            }
        }
    }

    fun switchRole(newRole: UserRole) {
        viewModelScope.launch {
            authRepository.switchRole(newRole)
        }
    }

    fun toggleDriverOnline() {
        viewModelScope.launch {
            val isOnline = authRepository.toggleDriverOnline()
            if (isOnline) {
                rideRepository.refreshPendingRequestsForDriver()
            }
        }
    }

    fun requestRide(
        pickup: LocationPoint,
        destination: LocationPoint,
        category: RideCategory,
        payment: PaymentMethod
    ) {
        val user = currentUser.value
        viewModelScope.launch {
            rideRepository.requestRide(
                passengerId = user?.id ?: "pax_guest",
                passengerName = user?.name ?: "Passageiro",
                passengerPhone = user?.phone ?: "+244 923 000 000",
                pickup = pickup,
                destination = destination,
                category = category,
                paymentMethod = payment
            )
        }
    }

    fun cancelActiveRide() {
        viewModelScope.launch {
            rideRepository.cancelActiveRide()
        }
    }

    fun stepActiveRideStatus() {
        val userId = currentUser.value?.id ?: "usr_current"
        viewModelScope.launch {
            rideRepository.advanceRideStatus(userId)
        }
    }

    fun submitRating(score: Int, comment: String) {
        viewModelScope.launch {
            rideRepository.submitRating(score, comment)
        }
    }

    fun acceptIncomingDriverRide(requestId: String) {
        val driverId = currentUser.value?.id ?: "drv_current"
        viewModelScope.launch {
            rideRepository.driverAcceptIncoming(requestId, driverId)
        }
    }

    fun rejectIncomingDriverRide(requestId: String) {
        viewModelScope.launch {
            rideRepository.driverRejectIncoming(requestId)
        }
    }

    fun refreshDriverPendingRequests() {
        viewModelScope.launch {
            rideRepository.refreshPendingRequestsForDriver()
        }
    }

    fun triggerSimulatedDriverIncomingTrip() {
        viewModelScope.launch {
            rideRepository.refreshPendingRequestsForDriver()
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
        }
    }
}
