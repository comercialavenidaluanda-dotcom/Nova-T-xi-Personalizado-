package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowOutward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaLightCard
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@Composable
fun EarningsScreen(
    todayEarningsAoa: Long = 0L,
    modifier: Modifier = Modifier
) {
    val aoaFormatter = remember { NumberFormat.getNumberInstance(Locale.GERMANY) }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NovaIce)
            .statusBarsPadding()
            .testTag("earnings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Os Seus Ganhos",
                        style = MaterialTheme.typography.headlineLarge,
                        color = NovaCharcoal,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Faturamento diário e repasses rápidos",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NovaTextSecondary
                    )
                }
                NovaBadge(text = "CONTA MOTORISTA", accentColor = NovaLime)
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Earnings Hero Card (White with warm gradient accent)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaOrange.copy(alpha = 0.15f))
                    .clip(RoundedCornerShape(26.dp)),
                color = NovaWhite
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SALDO DISPONÍVEL HOJE",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                            color = NovaTextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = NovaLime, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+18% vs ontem",
                                style = MaterialTheme.typography.labelSmall,
                                color = NovaLime,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${aoaFormatter.format(todayEarningsAoa)} Kz",
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 38.sp),
                        fontWeight = FontWeight.Black,
                        color = NovaCharcoal
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NovaGradientButton(
                            text = "LEVENTAR VIA MCX / KWIK",
                            brush = NovaGradients.OrangeSun,
                            leadingIcon = Icons.Default.ArrowOutward,
                            onClick = {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Levantamento de ${aoaFormatter.format(todayEarningsAoa)} Kz solicitado com sucesso para o Multicaixa Express!")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "withdraw_button"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Stats Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NovaLightCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Corridas", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "14", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = NovaCharcoal)
                        Text(text = "100% concluídas", style = MaterialTheme.typography.labelSmall, color = NovaLime)
                    }
                }
                NovaLightCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Distância", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "86 km", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = NovaCharcoal)
                        Text(text = "Luanda & Talatona", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                    }
                }
                NovaLightCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Gorjetas", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "4.200 Kz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = NovaOrange)
                        Text(text = "5 passageiros", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Repasses Recentes",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NovaCharcoal
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    PayoutItem(
                        method = "Multicaixa Express (MCX)",
                        date = "Hoje, 09:30",
                        amountAoa = 35000L,
                        aoaFormatter = aoaFormatter
                    )
                }
                item {
                    PayoutItem(
                        method = "KWiK Instantâneo",
                        date = "Ontem, 20:15",
                        amountAoa = 48000L,
                        aoaFormatter = aoaFormatter
                    )
                }
                item {
                    PayoutItem(
                        method = "Transferência IBAN",
                        date = "2 de Outubro",
                        amountAoa = 92000L,
                        aoaFormatter = aoaFormatter
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

@Composable
private fun PayoutItem(
    method: String,
    date: String,
    amountAoa: Long,
    aoaFormatter: NumberFormat
) {
    NovaLightCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NovaLime.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NovaLime, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = method, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NovaCharcoal)
                    Text(text = date, style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                }
            }
            Text(
                text = "+${aoaFormatter.format(amountAoa)} Kz",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = NovaLime
            )
        }
    }
}
