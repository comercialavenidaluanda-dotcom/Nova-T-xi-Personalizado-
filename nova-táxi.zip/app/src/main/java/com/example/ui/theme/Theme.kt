package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val NovaVibrantLightColorScheme = lightColorScheme(
    primary = NovaOrange,
    onPrimary = NovaWhite,
    primaryContainer = NovaOrange.copy(alpha = 0.12f),
    onPrimaryContainer = NovaOrangeDeep,
    secondary = NovaSun,
    onSecondary = NovaCharcoal,
    secondaryContainer = NovaSun.copy(alpha = 0.15f),
    onSecondaryContainer = NovaCharcoal,
    tertiary = NovaCoral,
    onTertiary = NovaWhite,
    tertiaryContainer = NovaCoral.copy(alpha = 0.12f),
    onTertiaryContainer = NovaCoral,
    background = NovaWhite,
    onBackground = NovaCharcoal,
    surface = NovaWhite,
    onSurface = NovaCharcoal,
    surfaceVariant = NovaIce,
    onSurfaceVariant = NovaTextSecondary,
    outline = NovaBorder,
    outlineVariant = NovaBorderLight,
    error = NovaCoral,
    onError = NovaWhite
)

val NovaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun NovaTaxiTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = NovaVibrantLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = NovaWhite.toArgb()
                window.navigationBarColor = NovaWhite.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = true
                    isAppearanceLightNavigationBars = true
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = NovaShapes,
        content = content
    )
}
