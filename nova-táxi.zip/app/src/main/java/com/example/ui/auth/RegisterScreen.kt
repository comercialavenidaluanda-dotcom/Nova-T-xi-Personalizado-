package com.example.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaBrandLogo
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaInputField
import com.example.core.designsystem.NovaSecondaryButton
import com.example.data.model.UserRole
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.launch

@Composable
fun RegisterScreen(
    initialRole: UserRole = UserRole.PASSENGER,
    onBackToLogin: () -> Unit,
    onRegisterPassenger: suspend (name: String, phone: String, email: String?, pass: String) -> Result<Unit>,
    onRegisterDriver: suspend (
        name: String,
        phone: String,
        email: String,
        pass: String,
        doc: String,
        license: String,
        brand: String,
        model: String,
        plate: String,
        color: String,
        year: Int
    ) -> Result<Unit>,
    onRegisterSuccess: (UserRole) -> Unit
) {
    var selectedRole by remember { mutableStateOf(initialRole) }
    var driverStep by remember { mutableIntStateOf(1) } // 1: Conta, 2: Documentos, 3: Viatura, 4: Conta em análise
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var isLoading by remember { mutableStateOf(false) }

    // Passenger Form
    var passengerName by remember { mutableStateOf("") }
    var passengerPhone by remember { mutableStateOf("+244 ") }
    var passengerPassword by remember { mutableStateOf("") }
    var passengerAcceptedTerms by remember { mutableStateOf(false) }

    // Driver Form
    var driverName by remember { mutableStateOf("") }
    var driverPhone by remember { mutableStateOf("+244 ") }
    var driverEmail by remember { mutableStateOf("") }
    var driverPassword by remember { mutableStateOf("") }
    var driverAcceptedTerms by remember { mutableStateOf(false) }

    var documentNumber by remember { mutableStateOf("") }
    var driverLicense by remember { mutableStateOf("") }
    var vehicleBrand by remember { mutableStateOf("") }
    var vehicleModel by remember { mutableStateOf("") }
    var licensePlate by remember { mutableStateOf("LD-") }
    var vehicleColor by remember { mutableStateOf("") }
    var vehicleYear by remember { mutableStateOf("2020") }
    var vehicleCategory by remember { mutableStateOf("COOL") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .testTag("register_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBackToLogin) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar",
                        tint = NovaCharcoal
                    )
                }
                NovaBrandLogo(compact = true)
                Box(modifier = Modifier.size(48.dp))
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (selectedRole == UserRole.PASSENGER) "Criar conta Passageiro" else "Quero ser Motorista NOVA",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 26.sp),
                color = NovaCharcoal,
                fontWeight = FontWeight.Black
            )
            Text(
                text = if (selectedRole == UserRole.PASSENGER)
                    "Cadastre-se em segundos para pedir viagens em Luanda."
                else
                    "Junte-se à maior rede de mobilidade e delivery em Angola.",
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextSecondary
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Role Selector Switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(NovaIce)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedRole == UserRole.PASSENGER) NovaOrange else Color.Transparent)
                        .clickable {
                            selectedRole = UserRole.PASSENGER
                            driverStep = 1
                        }
                        .padding(vertical = 12.dp)
                        .testTag("register_tab_passenger"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Passageiro",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selectedRole == UserRole.PASSENGER) NovaWhite else NovaTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedRole == UserRole.DRIVER) NovaLime else Color.Transparent)
                        .clickable { selectedRole = UserRole.DRIVER }
                        .padding(vertical = 12.dp)
                        .testTag("register_tab_driver"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Motorista",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selectedRole == UserRole.DRIVER) NovaCharcoal else NovaTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Card Content
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(16.dp, shape = RoundedCornerShape(24.dp), spotColor = NovaOrange.copy(alpha = 0.10f))
                    .clip(RoundedCornerShape(24.dp)),
                color = NovaWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    if (selectedRole == UserRole.PASSENGER) {
                        // 1. CADASTRO DO PASSAGEIRO — SIMPLES, SEM PAGAMENTO OBRIGATÓRIO
                        NovaBadge(text = "CADASTRO RÁPIDO", accentColor = NovaOrange)
                        Spacer(modifier = Modifier.height(14.dp))

                        NovaInputField(
                            value = passengerName,
                            onValueChange = { passengerName = it },
                            label = "Nome Completo",
                            placeholder = "Ex: Kizola Bernardo",
                            leadingIcon = Icons.Default.Person,
                            testTag = "reg_passenger_name"
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        NovaInputField(
                            value = passengerPhone,
                            onValueChange = { passengerPhone = it },
                            label = "Número de Telefone (+244)",
                            placeholder = "+244 9XX XXX XXX",
                            leadingIcon = Icons.Default.Phone,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            testTag = "reg_passenger_phone"
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        NovaInputField(
                            value = passengerPassword,
                            onValueChange = { passengerPassword = it },
                            label = "Palavra-passe (mínimo 6 caracteres)",
                            placeholder = "••••••••",
                            leadingIcon = Icons.Default.Lock,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            testTag = "reg_passenger_password"
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Terms and Privacy Checkbox
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = passengerAcceptedTerms,
                                onCheckedChange = { passengerAcceptedTerms = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = NovaOrange,
                                    uncheckedColor = NovaTextSecondary
                                ),
                                modifier = Modifier.testTag("reg_passenger_terms_check")
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Li e aceito os Termos de Serviço e a Política de Privacidade da NOVA Táxi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = NovaTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        NovaGradientButton(
                            text = if (isLoading) "A CRIAR CONTA..." else "CRIAR CONTA & ENTRAR",
                            brush = NovaGradients.OrangeSun,
                            enabled = !isLoading && passengerName.isNotBlank() && passengerPhone.length >= 9 && passengerPassword.length >= 6 && passengerAcceptedTerms,
                            onClick = {
                                isLoading = true
                                coroutineScope.launch {
                                    val result = onRegisterPassenger(
                                        passengerName.trim(),
                                        passengerPhone.trim(),
                                        null,
                                        passengerPassword
                                    )
                                    isLoading = false
                                    result.onSuccess {
                                        onRegisterSuccess(UserRole.PASSENGER)
                                    }.onFailure { error ->
                                        snackbarHostState.showSnackbar(
                                            error.message ?: "Erro ao criar conta de passageiro."
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "reg_passenger_submit_btn"
                        )
                    } else {
                        // 2. CADASTRO E ONBOARDING DO MOTORISTA — MULTI-ETAPAS COM STATUS "EM ANÁLISE"
                        when (driverStep) {
                            1 -> {
                                // ETAPA 1: CREDENCIAIS INICIAIS
                                NovaBadge(text = "ETAPA 1/3 • DADOS DA CONTA", accentColor = NovaLime)
                                Spacer(modifier = Modifier.height(14.dp))

                                NovaInputField(
                                    value = driverName,
                                    onValueChange = { driverName = it },
                                    label = "Nome Completo",
                                    placeholder = "Ex: Manuel Domingos",
                                    leadingIcon = Icons.Default.Person,
                                    testTag = "reg_driver_name"
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = driverPhone,
                                    onValueChange = { driverPhone = it },
                                    label = "Telefone (+244)",
                                    placeholder = "+244 9XX XXX XXX",
                                    leadingIcon = Icons.Default.Phone,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    testTag = "reg_driver_phone"
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = driverEmail,
                                    onValueChange = { driverEmail = it },
                                    label = "E-mail Profissional",
                                    placeholder = "motorista@novataxi.ao",
                                    leadingIcon = Icons.Default.Email,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    testTag = "reg_driver_email"
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = driverPassword,
                                    onValueChange = { driverPassword = it },
                                    label = "Palavra-passe (mínimo 6 caracteres)",
                                    placeholder = "••••••••",
                                    leadingIcon = Icons.Default.Lock,
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                    testTag = "reg_driver_password"
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = driverAcceptedTerms,
                                        onCheckedChange = { driverAcceptedTerms = it },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = NovaLime,
                                            uncheckedColor = NovaTextSecondary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Li e aceito os Termos para Motoristas Parceiros e Regulamento de Trânsito.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = NovaTextPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                NovaGradientButton(
                                    text = "CONTINUAR PARA DOCUMENTOS →",
                                    brush = NovaGradients.SunLime,
                                    enabled = driverName.isNotBlank() && driverPhone.length >= 9 && driverEmail.contains("@") && driverPassword.length >= 6 && driverAcceptedTerms,
                                    onClick = { driverStep = 2 },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            2 -> {
                                // ETAPA 2: DOCUMENTOS DO MOTORISTA
                                NovaBadge(text = "ETAPA 2/3 • DOCUMENTAÇÃO", accentColor = NovaSun)
                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "Insira os dados do seu documento de identificação e carta de condução válida.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NovaTextSecondary
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = documentNumber,
                                    onValueChange = { documentNumber = it.uppercase() },
                                    label = "Nº do Bilhete de Identidade (BI)",
                                    placeholder = "00XXXXXXXXXLAXXX",
                                    leadingIcon = Icons.Default.Badge,
                                    testTag = "reg_driver_doc"
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = driverLicense,
                                    onValueChange = { driverLicense = it.uppercase() },
                                    label = "Nº da Carta de Condução",
                                    placeholder = "AO-DL-XXXX-XXXX",
                                    leadingIcon = Icons.Default.Shield,
                                    testTag = "reg_driver_license"
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    NovaSecondaryButton(
                                        text = "← VOLTAR",
                                        onClick = { driverStep = 1 },
                                        modifier = Modifier.weight(1f)
                                    )
                                    NovaGradientButton(
                                        text = "DADOS DA VIATURA →",
                                        brush = NovaGradients.SunLime,
                                        enabled = documentNumber.isNotBlank() && driverLicense.isNotBlank(),
                                        onClick = { driverStep = 3 },
                                        modifier = Modifier.weight(1.5f)
                                    )
                                }
                            }
                            3 -> {
                                // ETAPA 3: VIATURA & SUBMISSÃO
                                NovaBadge(text = "ETAPA 3/3 • DADOS DA VIATURA", accentColor = NovaPurple)
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    NovaInputField(
                                        value = vehicleBrand,
                                        onValueChange = { vehicleBrand = it },
                                        label = "Marca",
                                        placeholder = "Toyota, Hyundai...",
                                        modifier = Modifier.weight(1f)
                                    )
                                    NovaInputField(
                                        value = vehicleModel,
                                        onValueChange = { vehicleModel = it },
                                        label = "Modelo",
                                        placeholder = "Corolla, i10...",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    NovaInputField(
                                        value = licensePlate,
                                        onValueChange = { licensePlate = it.uppercase() },
                                        label = "Matrícula",
                                        placeholder = "LD-XX-XX-XX",
                                        modifier = Modifier.weight(1f)
                                    )
                                    NovaInputField(
                                        value = vehicleColor,
                                        onValueChange = { vehicleColor = it },
                                        label = "Cor",
                                        placeholder = "Branco, Prata...",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))

                                NovaInputField(
                                    value = vehicleYear,
                                    onValueChange = { vehicleYear = it },
                                    label = "Ano de Fabrico",
                                    placeholder = "2020",
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    NovaSecondaryButton(
                                        text = "← VOLTAR",
                                        onClick = { driverStep = 2 },
                                        modifier = Modifier.weight(1f)
                                    )
                                    NovaGradientButton(
                                        text = if (isLoading) "A ENVIAR..." else "SUBMETER CANDIDATURA",
                                        brush = NovaGradients.SunLime,
                                        enabled = !isLoading && vehicleBrand.isNotBlank() && vehicleModel.isNotBlank() && licensePlate.isNotBlank(),
                                        onClick = {
                                            isLoading = true
                                            coroutineScope.launch {
                                                val yearInt = vehicleYear.toIntOrNull() ?: 2020
                                                val result = onRegisterDriver(
                                                    driverName.trim(),
                                                    driverPhone.trim(),
                                                    driverEmail.trim(),
                                                    driverPassword,
                                                    documentNumber.trim(),
                                                    driverLicense.trim(),
                                                    vehicleBrand.trim(),
                                                    vehicleModel.trim(),
                                                    licensePlate.trim(),
                                                    vehicleColor.trim(),
                                                    yearInt
                                                )
                                                isLoading = false
                                                result.onSuccess {
                                                    driverStep = 4 // Tela "Conta em análise"
                                                }.onFailure { error ->
                                                    snackbarHostState.showSnackbar(
                                                        error.message ?: "Erro ao submeter cadastro de motorista."
                                                    )
                                                }
                                            }
                                        },
                                        modifier = Modifier.weight(1.8f)
                                    )
                                }
                            }
                            4 -> {
                                // ETAPA 4: CONTA EM ANÁLISE
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(NovaSun.copy(alpha = 0.20f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = "⏳", fontSize = 32.sp)
                                    }
                                    Spacer(modifier = Modifier.height(14.dp))

                                    Text(
                                        text = "Conta em Análise",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Black,
                                        color = NovaCharcoal
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = "O seu registo e documentação foram submetidos com sucesso ao backend da NOVA Táxi. A nossa equipa de operações está a verificar os seus documentos e viatura. Entraremos em contacto brevemente.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = NovaTextSecondary,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        color = NovaIce,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = NovaLime, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Registo criado no Supabase", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = NovaCharcoal)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = NovaLime, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Viatura associada ao perfil", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = NovaCharcoal)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaSun))
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text("Aprovação pendente da equipa NOVA", style = MaterialTheme.typography.labelMedium, color = NovaOrange, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    NovaGradientButton(
                                        text = "ENTRAR NO PAINEL (MODO ANÁLISE)",
                                        brush = NovaGradients.OrangeSun,
                                        onClick = { onRegisterSuccess(UserRole.DRIVER) },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Footer Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Já tem uma conta criada? ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaTextSecondary
                )
                Text(
                    text = "Iniciar Sessão",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = NovaOrange,
                    modifier = Modifier.clickable { onBackToLogin() }
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}
