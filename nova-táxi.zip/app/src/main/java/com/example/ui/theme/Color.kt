package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// NOVA Light & Vibrant Palette - ZERO BLUE
val NovaWhite = Color(0xFFFFFFFF)
val NovaIce = Color(0xFFF8FAFC)
val NovaSurfaceLight = Color(0xFFF1F5F9)
val NovaCardLight = Color(0xFFFFFFFF)

// Primary Action Colors
val NovaOrange = Color(0xFFFF6B00)
val NovaOrangeDeep = Color(0xFFEA580C)
val NovaSun = Color(0xFFFFC700)
val NovaCoral = Color(0xFFFF4757)
val NovaLime = Color(0xFF10B981)
val NovaPurple = Color(0xFF8B5CF6)
val NovaPurpleDeep = Color(0xFF7C3AED)

// High-contrast Charcoal / Neutral Typography
val NovaCharcoal = Color(0xFF0F172A)
val NovaTextPrimary = Color(0xFF1E293B)
val NovaTextSecondary = Color(0xFF64748B)
val NovaTextTertiary = Color(0xFF94A3B8)
val NovaBorder = Color(0xFFE2E8F0)
val NovaBorderLight = Color(0xFFF1F5F9)

// Warm Gradients (NO BLUE)
object NovaGradients {
    val OrangeSun = Brush.linearGradient(
        colors = listOf(NovaOrange, NovaSun)
    )
    val OrangeCoral = Brush.linearGradient(
        colors = listOf(NovaOrange, NovaCoral)
    )
    val SunLime = Brush.linearGradient(
        colors = listOf(NovaSun, NovaLime)
    )
    val PurpleVip = Brush.linearGradient(
        colors = listOf(NovaPurple, NovaCoral)
    )
    val CardSubtle = Brush.verticalGradient(
        colors = listOf(NovaWhite, NovaIce)
    )
    val WarmHero = Brush.verticalGradient(
        colors = listOf(
            NovaOrange.copy(alpha = 0.08f),
            NovaWhite
        )
    )
}
