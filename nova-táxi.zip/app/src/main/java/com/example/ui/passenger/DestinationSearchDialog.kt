package com.example.ui.passenger

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaGradientButton
import com.example.core.location.PlacesSearchService
import com.example.data.model.LocationPoint
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaTextTertiary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class DestinationSearchState {
    object Idle : DestinationSearchState()
    object Searching : DestinationSearchState()
    data class Results(val suggestions: List<LocationPoint>) : DestinationSearchState()
    object NoResults : DestinationSearchState()
    data class Selected(val location: LocationPoint) : DestinationSearchState()
}

@Composable
fun DestinationSearchDialog(
    pickupLocation: LocationPoint,
    initialQuery: String = "",
    recentDestinations: List<LocationPoint> = emptyList(),
    onDestinationConfirmed: (LocationPoint) -> Unit,
    onChooseOnMapClick: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val placesService = remember { PlacesSearchService(context) }
    val coroutineScope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf(initialQuery) }
    var searchState by remember { mutableStateOf<DestinationSearchState>(DestinationSearchState.Idle) }
    var candidateLocation by remember { mutableStateOf<LocationPoint?>(null) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    LaunchedEffect(searchQuery) {
        if (searchQuery.trim().isEmpty()) {
            searchJob?.cancel()
            searchState = DestinationSearchState.Idle
            return@LaunchedEffect
        }

        searchJob?.cancel()
        searchJob = launch {
            delay(250) // Debounce rápido
            searchState = DestinationSearchState.Searching
            val results = placesService.searchPlaces(searchQuery, pickupLocation)
            searchState = if (results.isEmpty()) {
                DestinationSearchState.NoResults
            } else {
                DestinationSearchState.Results(results)
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .statusBarsPadding()
            .imePadding()
            .testTag("destination_search_dialog"),
        color = NovaWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            // Header: Back button + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("search_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar",
                        tint = NovaCharcoal
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Para onde vamos?",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = NovaCharcoal
                    )
                    Text(
                        text = "Pesquise ou escolha o ponto de destino em Luanda",
                        style = MaterialTheme.typography.bodySmall,
                        color = NovaTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Pickup Indicator
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = NovaIce,
                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NovaOrange))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "PONTO DE PARTIDA",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = FontWeight.Bold,
                            color = NovaTextSecondary
                        )
                        Text(
                            text = pickupLocation.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = NovaCharcoal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Text Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    candidateLocation = null
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("destination_search_input"),
                placeholder = {
                    Text("Escreva o local, rua ou bairro...", color = NovaTextTertiary)
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = NovaOrange)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = {
                            searchQuery = ""
                            candidateLocation = null
                            searchState = DestinationSearchState.Idle
                        }) {
                            Icon(Icons.Default.Clear, contentDescription = "Limpar", tint = NovaTextSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaOrange,
                    unfocusedBorderColor = NovaBorder,
                    focusedContainerColor = NovaWhite,
                    unfocusedContainerColor = NovaIce
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // "Escolher no mapa" Quick Option Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onChooseOnMapClick() }
                    .border(1.dp, NovaOrange.copy(alpha = 0.35f), RoundedCornerShape(14.dp)),
                color = NovaOrange.copy(alpha = 0.08f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Map,
                        contentDescription = null,
                        tint = NovaOrange,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Escolher diretamente no mapa",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NovaOrange
                        )
                        Text(
                            text = "Aponte o pino no mapa de Luanda",
                            style = MaterialTheme.typography.bodySmall,
                            color = NovaTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Selected Candidate Card (When user clicks a suggestion)
            AnimatedVisibility(visible = candidateLocation != null) {
                val candidate = candidateLocation
                if (candidate != null) {
                    val distanceKm = placesService.calculateDistanceKm(pickupLocation, candidate)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .shadow(12.dp, shape = RoundedCornerShape(18.dp), spotColor = NovaOrange.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(18.dp),
                        color = NovaWhite,
                        border = androidx.compose.foundation.BorderStroke(2.dp, NovaOrange)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            NovaBadge(text = "DESTINO SELECIONADO", accentColor = NovaOrange)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = candidate.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = NovaCharcoal
                            )
                            Text(
                                text = candidate.address,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NovaTextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Distância estimada: $distanceKm km",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = NovaOrange
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            NovaGradientButton(
                                text = "CONFIRMAR DESTINO →",
                                brush = NovaGradients.OrangeSun,
                                onClick = { onDestinationConfirmed(candidate) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("confirm_destination_button")
                            )
                        }
                    }
                }
            }

            // Results / Empty / Suggestions Content
            when (val state = searchState) {
                is DestinationSearchState.Searching -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = NovaOrange, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "A procurar locais em Luanda...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }

                is DestinationSearchState.NoResults -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "🔎", fontSize = 36.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Não encontramos este local",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NovaCharcoal
                            )
                            Text(
                                text = "Tente escrever outro nome de rua ou utilize a opção 'Escolher no mapa'.",
                                style = MaterialTheme.typography.bodySmall,
                                color = NovaTextSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                }

                is DestinationSearchState.Results -> {
                    Text(
                        text = "Sugestões encontradas (${state.suggestions.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NovaTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(state.suggestions) { suggestion ->
                            val dist = placesService.calculateDistanceKm(pickupLocation, suggestion)
                            PlaceSuggestionItem(
                                place = suggestion,
                                distanceKm = dist,
                                isSelected = candidateLocation?.id == suggestion.id,
                                onClick = {
                                    // REGRA DE OURO: Apenas define como candidato após clique explícito!
                                    candidateLocation = suggestion
                                }
                            )
                            HorizontalDivider(color = NovaBorderLight)
                        }
                    }
                }

                is DestinationSearchState.Idle -> {
                    if (recentDestinations.isNotEmpty()) {
                        Text(
                            text = "Destinos Recentes / Favoritos",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NovaCharcoal
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(recentDestinations) { place ->
                                val dist = placesService.calculateDistanceKm(pickupLocation, place)
                                PlaceSuggestionItem(
                                    place = place,
                                    distanceKm = dist,
                                    isSelected = candidateLocation?.id == place.id,
                                    onClick = {
                                        // Clique explícito
                                        candidateLocation = place
                                    }
                                )
                                HorizontalDivider(color = NovaBorderLight)
                            }
                        }
                    } else {
                        // Empty Prompt
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "📍", fontSize = 36.sp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Para onde quer viajar?",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaCharcoal
                                )
                                Text(
                                    text = "Digite acima o nome do shopping, hotel, aeroporto ou bairro em Luanda.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NovaTextSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 30.dp)
                                )
                            }
                        }
                    }
                }

                else -> {}
            }
        }
    }
}

@Composable
private fun PlaceSuggestionItem(
    place: LocationPoint,
    distanceKm: Double,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("suggestion_item_${place.id}"),
        color = if (isSelected) NovaOrange.copy(alpha = 0.10f) else Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) NovaOrange else NovaIce),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = if (isSelected) NovaWhite else NovaOrange,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = place.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = NovaCharcoal
                )
                Text(
                    text = place.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = NovaTextSecondary,
                    maxLines = 1
                )
            }
            if (distanceKm > 0) {
                Text(
                    text = "$distanceKm km",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = NovaOrange
                )
            }
        }
    }
}
