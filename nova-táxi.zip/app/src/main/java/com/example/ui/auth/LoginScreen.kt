package com.example.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBrandLogo
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaInputField
import com.example.data.model.UserRole
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onLoginSuccess: (UserRole) -> Unit,
    onNavigateToRegister: () -> Unit,
    onNavigateToRoleSelection: () -> Unit,
    onLoginAction: suspend (String, String) -> Result<UserRole>
) {
    var identifier by remember { mutableStateOf("+244 923 456 789") }
    var password by remember { mutableStateOf("123456") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var selectedRole by remember { mutableStateOf(UserRole.PASSENGER) }

    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .testTag("login_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(16.dp))

                NovaBrandLogo(compact = false)

                Spacer(modifier = Modifier.height(28.dp))

                // Card with Role Switcher
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaOrange.copy(alpha = 0.12f))
                        .clip(RoundedCornerShape(26.dp)),
                    color = NovaWhite,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                ) {
                    Column(modifier = Modifier.padding(22.dp)) {
                        Text(
                            text = "Entrar na sua conta",
                            style = MaterialTheme.typography.headlineMedium,
                            color = NovaCharcoal,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Acesso rápido e seguro à plataforma NOVA Táxi",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NovaTextSecondary
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Role Selector Pills
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(NovaIce)
                                .padding(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedRole == UserRole.PASSENGER) NovaOrange else Color.Transparent)
                                    .clickable { selectedRole = UserRole.PASSENGER }
                                    .padding(vertical = 10.dp)
                                    .testTag("login_role_passenger"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Passageiro",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selectedRole == UserRole.PASSENGER) NovaWhite else NovaTextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedRole == UserRole.DRIVER) NovaLime else Color.Transparent)
                                    .clickable { selectedRole = UserRole.DRIVER }
                                    .padding(vertical = 10.dp)
                                    .testTag("login_role_driver"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Motorista",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selectedRole == UserRole.DRIVER) NovaWhite else NovaTextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        NovaInputField(
                            value = identifier,
                            onValueChange = { identifier = it },
                            label = "Telefone ou E-mail",
                            placeholder = "+244 9XX XXX XXX ou email@exemplo.ao",
                            leadingIcon = Icons.Default.Phone,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            testTag = "login_identifier_input"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        NovaInputField(
                            value = password,
                            onValueChange = { password = it },
                            label = "Palavra-passe",
                            placeholder = "••••••••",
                            leadingIcon = Icons.Default.Lock,
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingAction = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Alternar visibilidade",
                                        tint = NovaTextSecondary
                                    )
                                }
                            },
                            testTag = "login_password_input"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "Recuperar acesso?",
                                style = MaterialTheme.typography.labelMedium,
                                color = NovaOrange,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Enviamos um SMS com código de recuperação para o seu número.")
                                        }
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        if (isLoading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = NovaOrange)
                            }
                        } else {
                            NovaGradientButton(
                                text = if (selectedRole == UserRole.PASSENGER) "ENTRAR COMO PASSAGEIRO" else "ENTRAR COMO MOTORISTA",
                                brush = if (selectedRole == UserRole.PASSENGER) NovaGradients.OrangeSun else NovaGradients.SunLime,
                                onClick = {
                                    isLoading = true
                                    coroutineScope.launch {
                                        val result = onLoginAction(
                                            if (selectedRole == UserRole.DRIVER) "motorista_$identifier" else identifier,
                                            password
                                        )
                                        isLoading = false
                                        result.onSuccess { role ->
                                            onLoginSuccess(role)
                                        }.onFailure { err ->
                                            snackbarHostState.showSnackbar(err.message ?: "Erro ao entrar")
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "login_submit_button"
                            )
                        }
                    }
                }
            }

            // Bottom Register Link
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Ainda não tem conta? ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NovaTextSecondary
                    )
                    Text(
                        text = "Criar conta NOVA",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = NovaOrange,
                        modifier = Modifier
                            .clickable { onNavigateToRegister() }
                            .testTag("login_to_register_button")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Escolher perfil detalhado",
                    style = MaterialTheme.typography.labelSmall,
                    color = NovaTextSecondary,
                    modifier = Modifier.clickable { onNavigateToRoleSelection() }
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}
