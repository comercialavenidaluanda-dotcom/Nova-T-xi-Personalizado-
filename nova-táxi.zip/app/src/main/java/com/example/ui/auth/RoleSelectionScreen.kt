package com.example.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaBrandLogo
import com.example.core.designsystem.NovaGradientButton
import com.example.data.model.UserRole
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite

@Composable
fun RoleSelectionScreen(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit
) {
    var selected by remember { mutableStateOf(currentRole) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp)
            .testTag("role_selection_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(10.dp))
                NovaBrandLogo(compact = false)

                Spacer(modifier = Modifier.height(28.dp))

                Text(
                    text = "Como deseja usar o NOVA?",
                    style = MaterialTheme.typography.headlineLarge,
                    color = NovaCharcoal,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Alterne entre os perfis a qualquer momento",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaTextSecondary
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Option 1: PASSENGER
                RoleOptionCardLight(
                    title = "Passageiro",
                    badge = "PEDIR & VIAJAR",
                    subtitle = "Desloque-se por Luanda com conforto, rapidez e pagamento por Multicaixa Express ou KWiK.",
                    icon = Icons.Default.Person,
                    accentColor = NovaOrange,
                    isSelected = selected == UserRole.PASSENGER,
                    onClick = { selected = UserRole.PASSENGER },
                    perks = listOf(
                        "Categorias COOL, EXECUTIVO, VIP e BIKE",
                        "Estimativa em tempo real em Kwanzas (Kz)",
                        "Mapa claro com motoristas ao vivo"
                    ),
                    testTag = "role_card_passenger"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Option 2: DRIVER
                RoleOptionCardLight(
                    title = "Motorista",
                    badge = "CONDUZIR & FATURAR",
                    subtitle = "Receba solicitações de corridas e faça repasses imediatos para o seu Multicaixa Express.",
                    icon = Icons.Default.DirectionsCar,
                    accentColor = NovaLime,
                    isSelected = selected == UserRole.DRIVER,
                    onClick = { selected = UserRole.DRIVER },
                    perks = listOf(
                        "Radar de chamadas com contagem regressiva",
                        "Visão diária de faturamento e gorjetas em AOA",
                        "Suporte e verificação dedicada"
                    ),
                    testTag = "role_card_driver"
                )
            }

            NovaGradientButton(
                text = if (selected == UserRole.PASSENGER) "CONTINUAR COMO PASSAGEIRO" else "CONTINUAR COMO MOTORISTA",
                brush = if (selected == UserRole.PASSENGER) NovaGradients.OrangeSun else NovaGradients.SunLime,
                leadingIcon = Icons.AutoMirrored.Filled.ArrowForward,
                onClick = { onRoleSelected(selected) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "role_confirm_button"
            )
        }
    }
}

@Composable
private fun RoleOptionCardLight(
    title: String,
    badge: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: androidx.compose.ui.graphics.Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    perks: List<String>,
    testTag: String
) {
    val borderColor = if (isSelected) accentColor else NovaBorder

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(if (isSelected) 14.dp else 4.dp, shape = RoundedCornerShape(22.dp), spotColor = accentColor.copy(alpha = 0.2f))
            .clip(RoundedCornerShape(22.dp))
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(22.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(22.dp),
        color = if (isSelected) accentColor.copy(alpha = 0.06f) else NovaWhite
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = NovaCharcoal
                        )
                        NovaBadge(text = badge, accentColor = accentColor)
                    }
                }

                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .border(2.dp, if (isSelected) accentColor else NovaBorder, CircleShape)
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(accentColor)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextPrimary
            )

            Spacer(modifier = Modifier.height(10.dp))

            perks.forEach { perk ->
                Row(
                    modifier = Modifier.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = perk,
                        style = MaterialTheme.typography.labelSmall,
                        color = NovaTextSecondary
                    )
                }
            }
        }
    }
}
