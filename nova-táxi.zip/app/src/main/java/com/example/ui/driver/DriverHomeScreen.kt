package com.example.ui.driver

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.BottomNavItem
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaBottomBar
import com.example.core.designsystem.NovaGradientButton
import com.example.core.designsystem.NovaLightCard
import com.example.core.designsystem.NovaPulseDot
import com.example.core.designsystem.NovaSecondaryButton
import com.example.data.model.ActiveDriver
import com.example.data.model.RideRequest
import com.example.data.model.RideStatus
import com.example.data.model.User
import com.example.ui.components.NovaMapCanvas
import com.example.ui.screens.EarningsScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RidesHistoryScreen
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaGradients
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale

@Composable
fun DriverHomeScreen(
    currentUser: User?,
    nearbyDrivers: List<ActiveDriver>,
    activeRide: RideRequest?,
    incomingRequest: RideRequest?,
    rideHistory: List<RideRequest>,
    onToggleOnline: () -> Unit,
    onAcceptIncomingRide: (String) -> Unit,
    onRejectIncomingRide: (String) -> Unit,
    onStepActiveRide: () -> Unit,
    onCancelActiveRide: () -> Unit,
    onSimulateIncomingRequest: () -> Unit,
    onSwitchToPassenger: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("home") }
    val isOnline = currentUser?.driverProfile?.isOnline ?: true
    val profile = currentUser?.driverProfile
    val aoaFormatter = remember { NumberFormat.getNumberInstance(Locale.GERMANY) }

    // 15s Countdown
    var countdown by remember { mutableIntStateOf(15) }
    LaunchedEffect(incomingRequest) {
        if (incomingRequest != null) {
            countdown = 15
            while (countdown > 0) {
                delay(1000)
                countdown--
            }
            if (countdown == 0) {
                onRejectIncomingRide(incomingRequest.id)
            }
        }
    }

    val driverNavItems = listOf(
        BottomNavItem("home", "Início", Icons.Default.Home),
        BottomNavItem("rides", "Corridas", Icons.Default.DirectionsCar),
        BottomNavItem("earnings", "Ganhos", Icons.Default.AccountBalanceWallet),
        BottomNavItem("notifications", "Notificações", Icons.Default.Notifications, badgeCount = 1),
        BottomNavItem("profile", "Perfil", Icons.Default.Person)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaWhite)
            .testTag("driver_root_container")
    ) {
        when (selectedTab) {
            "rides" -> {
                RidesHistoryScreen(
                    rides = rideHistory,
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            "earnings" -> {
                EarningsScreen(
                    todayEarningsAoa = profile?.earningsTodayAoa ?: 0L,
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            "notifications" -> {
                NotificationsScreen(
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            "profile" -> {
                ProfileScreen(
                    currentUser = currentUser,
                    onSwitchRole = onSwitchToPassenger,
                    onLogout = onLogout,
                    onNavigateToHistory = { selectedTab = "rides" },
                    modifier = Modifier.padding(bottom = 68.dp)
                )
            }
            else -> {
                // Main Driver Cockpit & Map
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 68.dp)
                ) {
                    NovaMapCanvas(
                        modifier = Modifier.fillMaxSize(),
                        pickupLocation = incomingRequest?.pickup ?: activeRide?.pickup,
                        destinationLocation = incomingRequest?.destination ?: activeRide?.destination,
                        drivers = nearbyDrivers,
                        hasActiveRoute = activeRide != null || incomingRequest != null
                    )

                    // Top Dashboard Card
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .shadow(12.dp, shape = RoundedCornerShape(22.dp), spotColor = NovaOrange.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(22.dp),
                        color = NovaWhite,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Bom dia 👋",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Black,
                                        color = NovaCharcoal
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = currentUser?.name ?: "Motorista NOVA",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = NovaTextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.Verified, contentDescription = null, tint = NovaLime, modifier = Modifier.size(16.dp))
                                    }
                                }

                                // Online / Offline Indicator Pill
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable { onToggleOnline() }
                                        .border(1.dp, if (isOnline) NovaLime else NovaBorder, RoundedCornerShape(20.dp)),
                                    color = if (isOnline) NovaLime.copy(alpha = 0.12f) else NovaIce
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        NovaPulseDot(color = if (isOnline) NovaLime else NovaCoral, size = 6.dp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isOnline) "ONLINE" else "OFFLINE",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isOnline) NovaLime else NovaCoral
                                        )
                                    }
                                }
                            }

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = NovaBorderLight
                            )

                            // Quick Stats Grid: Ganhos, Corridas, Avaliação
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "Ganhos Hoje", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                                    Text(
                                        text = "${aoaFormatter.format(profile?.earningsTodayAoa ?: 0L)} Kz",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = NovaOrange
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "Corridas", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                                    Text(text = "${profile?.totalRides ?: 0}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NovaCharcoal)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "Avaliação", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Star, contentDescription = null, tint = NovaSun, modifier = Modifier.size(14.dp))
                                        Text(text = "${profile?.rating ?: 5.0}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NovaCharcoal)
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Floating Cockpit: Online toggle or incoming request or active ride
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        if (incomingRequest != null) {
                            // "NOVA SOLICITAÇÃO" Sheet
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(24.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaOrange.copy(alpha = 0.25f))
                                    .clip(RoundedCornerShape(26.dp)),
                                color = NovaWhite,
                                border = androidx.compose.foundation.BorderStroke(2.dp, NovaOrange)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        NovaBadge(text = "NOVA SOLICITAÇÃO", accentColor = NovaOrange)
                                        Text(
                                            text = "${countdown}s",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Black,
                                            color = if (countdown <= 5) NovaCoral else NovaOrange
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    LinearProgressIndicator(
                                        progress = { countdown / 15f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(CircleShape),
                                        color = NovaOrange,
                                        trackColor = NovaBorderLight
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = "Valor Estimado", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                                            Text(
                                                text = "${aoaFormatter.format(incomingRequest.priceAoa)} Kz",
                                                style = MaterialTheme.typography.displayMedium.copy(fontSize = 26.sp),
                                                fontWeight = FontWeight.Black,
                                                color = NovaOrange
                                            )
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "Distância & Tempo", style = MaterialTheme.typography.labelSmall, color = NovaTextSecondary)
                                            Text(
                                                text = "${incomingRequest.distanceKm} km • ${incomingRequest.etaMinutes} min",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = NovaCharcoal
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Pickup & Destination info
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(NovaIce)
                                            .padding(12.dp)
                                    ) {
                                        Text(
                                            text = "📍 Recolha: ${incomingRequest.pickup.name}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = NovaCharcoal
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "🏁 Destino: ${incomingRequest.destination.name}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = NovaCoral
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        NovaSecondaryButton(
                                            text = "RECUSAR",
                                            onClick = { onRejectIncomingRide(incomingRequest.id) },
                                            modifier = Modifier.weight(1f)
                                        )

                                        NovaGradientButton(
                                            text = "ACEITAR CORRIDA",
                                            brush = NovaGradients.OrangeSun,
                                            onClick = { onAcceptIncomingRide(incomingRequest.id) },
                                            modifier = Modifier.weight(1.5f),
                                            testTag = "button_aceitar_corrida"
                                        )
                                    }
                                }
                            }
                        } else if (activeRide != null) {
                            // Active Ride In-Progress Cockpit
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(20.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaCharcoal.copy(alpha = 0.12f))
                                    .clip(RoundedCornerShape(26.dp)),
                                color = NovaWhite,
                                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            NovaBadge(text = "CORRIDA EM CURSO", accentColor = NovaLime)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = activeRide.status.displayTitle,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = NovaCharcoal
                                            )
                                        }
                                        NovaPulseDot(color = NovaLime, size = 10.dp)
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(16.dp)),
                                        color = NovaIce
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(
                                                    text = activeRide.passengerName,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NovaCharcoal
                                                )
                                                Text(
                                                    text = activeRide.passengerPhone,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = NovaOrange
                                                )
                                            }
                                            Text(
                                                text = "${aoaFormatter.format(activeRide.priceAoa)} Kz",
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Black,
                                                color = NovaOrange
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        NovaSecondaryButton(
                                            text = "CANCELAR",
                                            onClick = onCancelActiveRide,
                                            modifier = Modifier.weight(1f)
                                        )
                                        NovaGradientButton(
                                            text = when (activeRide.status) {
                                                RideStatus.ACCEPTED -> "CHEGUEI AO LOCAL"
                                                RideStatus.ARRIVED -> "INICIAR VIAGEM"
                                                RideStatus.IN_PROGRESS -> "FINALIZAR & RECEBER (CASH)"
                                                RideStatus.COMPLETED -> "NOVA CORRIDA"
                                                else -> "AVANÇAR"
                                            },
                                            brush = NovaGradients.OrangeSun,
                                            onClick = onStepActiveRide,
                                            modifier = Modifier.weight(1.8f)
                                        )
                                    }
                                }
                            }
                        } else {
                            // Driver Idle Card with Big "FICAR ONLINE" button
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(20.dp, shape = RoundedCornerShape(26.dp), spotColor = NovaCharcoal.copy(alpha = 0.10f))
                                    .clip(RoundedCornerShape(26.dp)),
                                color = NovaWhite,
                                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            NovaPulseDot(color = if (isOnline) NovaLime else NovaCoral, size = 8.dp)
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (isOnline) "Pronto para receber corridas" else "Você está Offline",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NovaCharcoal
                                                )
                                                Text(
                                                    text = if (isOnline) "Alta procura em Luanda" else "Fique online para faturar",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = NovaTextSecondary
                                                )
                                            }
                                        }

                                        NovaSecondaryButton(
                                            text = "SIMULAR PEDIDO",
                                            onClick = onSimulateIncomingRequest,
                                            testTag = "simulate_ride_prompt"
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Big Action Button: "FICAR ONLINE" / "FICAR OFFLINE"
                                    NovaGradientButton(
                                        text = if (isOnline) "FICAR OFFLINE (PAUSA)" else "FICAR ONLINE",
                                        brush = if (isOnline) NovaGradients.OrangeCoral else NovaGradients.SunLime,
                                        leadingIcon = Icons.Default.PowerSettingsNew,
                                        onClick = onToggleOnline,
                                        modifier = Modifier.fillMaxWidth(),
                                        testTag = "button_ficar_online"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Driver Bottom Navigation Bar
        NovaBottomBar(
            items = driverNavItems,
            selectedId = selectedTab,
            onItemSelected = { selectedTab = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
