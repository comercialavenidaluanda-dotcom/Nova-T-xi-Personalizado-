package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.model.UserRole
import com.example.ui.NovaViewModel
import com.example.ui.auth.LoginScreen
import com.example.ui.auth.RegisterScreen
import com.example.ui.auth.RoleSelectionScreen
import com.example.ui.auth.SplashScreen
import com.example.ui.driver.DriverHomeScreen
import com.example.ui.passenger.PassengerHomeScreen
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

object NovaDestinations {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val ROLE_SELECTION = "role_selection"
    const val PASSENGER_HOME = "passenger_home"
    const val DRIVER_HOME = "driver_home"
}

@Composable
fun NovaNavGraph(
    viewModel: NovaViewModel,
    navController: NavHostController = rememberNavController()
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val activeRide by viewModel.activeRide.collectAsStateWithLifecycle()
    val nearbyDrivers by viewModel.nearbyDrivers.collectAsStateWithLifecycle()
    val incomingDriverRequest by viewModel.incomingDriverRequest.collectAsStateWithLifecycle()
    val rideHistory by viewModel.rideHistory.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = NovaDestinations.SPLASH
    ) {
        composable(NovaDestinations.SPLASH) {
            SplashScreen(
                onNavigateNext = {
                    if (currentUser == null) {
                        navController.navigate(NovaDestinations.LOGIN) {
                            popUpTo(NovaDestinations.SPLASH) { inclusive = true }
                        }
                    } else {
                        val destination = if (currentUser?.role == UserRole.DRIVER) {
                            NovaDestinations.DRIVER_HOME
                        } else {
                            NovaDestinations.PASSENGER_HOME
                        }
                        navController.navigate(destination) {
                            popUpTo(NovaDestinations.SPLASH) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(NovaDestinations.LOGIN) {
            LoginScreen(
                onLoginSuccess = { role ->
                    if (role == UserRole.DRIVER) {
                        navController.navigate(NovaDestinations.DRIVER_HOME) {
                            popUpTo(NovaDestinations.LOGIN) { inclusive = true }
                        }
                    } else {
                        navController.navigate(NovaDestinations.PASSENGER_HOME) {
                            popUpTo(NovaDestinations.LOGIN) { inclusive = true }
                        }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(NovaDestinations.REGISTER)
                },
                onNavigateToRoleSelection = {
                    navController.navigate(NovaDestinations.ROLE_SELECTION)
                },
                onLoginAction = { identifier, pass ->
                    suspendCoroutine { cont ->
                        viewModel.login(identifier, pass) { result ->
                            cont.resume(result)
                        }
                    }
                }
            )
        }

        composable(NovaDestinations.REGISTER) {
            RegisterScreen(
                initialRole = currentUser?.role ?: UserRole.PASSENGER,
                onBackToLogin = {
                    navController.popBackStack()
                },
                onRegisterPassenger = { name, phone, email, pass ->
                    suspendCoroutine { cont ->
                        viewModel.registerPassenger(name, phone, email, pass) { res ->
                            cont.resume(res)
                        }
                    }
                },
                onRegisterDriver = { name, phone, email, pass, doc, lic, brand, model, plate, color, year ->
                    suspendCoroutine { cont ->
                        viewModel.registerDriver(name, phone, email, pass, doc, lic, brand, model, plate, color, year) { res ->
                            cont.resume(res)
                        }
                    }
                },
                onRegisterSuccess = { role ->
                    if (role == UserRole.DRIVER) {
                        navController.navigate(NovaDestinations.DRIVER_HOME) {
                            popUpTo(NovaDestinations.REGISTER) { inclusive = true }
                        }
                    } else {
                        navController.navigate(NovaDestinations.PASSENGER_HOME) {
                            popUpTo(NovaDestinations.REGISTER) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(NovaDestinations.ROLE_SELECTION) {
            RoleSelectionScreen(
                currentRole = currentUser?.role ?: UserRole.PASSENGER,
                onRoleSelected = { role ->
                    viewModel.switchRole(role)
                    if (role == UserRole.DRIVER) {
                        navController.navigate(NovaDestinations.DRIVER_HOME) {
                            popUpTo(NovaDestinations.ROLE_SELECTION) { inclusive = true }
                        }
                    } else {
                        navController.navigate(NovaDestinations.PASSENGER_HOME) {
                            popUpTo(NovaDestinations.ROLE_SELECTION) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(NovaDestinations.PASSENGER_HOME) {
            PassengerHomeScreen(
                currentUser = currentUser,
                nearbyDrivers = nearbyDrivers,
                activeRide = activeRide,
                rideHistory = rideHistory,
                onRequestRide = { pickup, dest, cat, pay ->
                    viewModel.requestRide(pickup, dest, cat, pay)
                },
                onCancelRide = {
                    viewModel.cancelActiveRide()
                },
                onStepRideStatus = {
                    viewModel.stepActiveRideStatus()
                },
                onSubmitRating = { score, comment ->
                    viewModel.submitRating(score, comment)
                },
                onSwitchToDriver = {
                    viewModel.switchRole(UserRole.DRIVER)
                    navController.navigate(NovaDestinations.DRIVER_HOME) {
                        popUpTo(NovaDestinations.PASSENGER_HOME) { inclusive = true }
                    }
                },
                onLogout = {
                    viewModel.logout()
                    navController.navigate(NovaDestinations.LOGIN) {
                        popUpTo(NovaDestinations.PASSENGER_HOME) { inclusive = true }
                    }
                }
            )
        }

        composable(NovaDestinations.DRIVER_HOME) {
            DriverHomeScreen(
                currentUser = currentUser,
                nearbyDrivers = nearbyDrivers,
                activeRide = activeRide,
                incomingRequest = incomingDriverRequest,
                rideHistory = rideHistory,
                onToggleOnline = {
                    viewModel.toggleDriverOnline()
                },
                onAcceptIncomingRide = { rideId ->
                    viewModel.acceptIncomingDriverRide(rideId)
                },
                onRejectIncomingRide = { rideId ->
                    viewModel.rejectIncomingDriverRide(rideId)
                },
                onStepActiveRide = {
                    viewModel.stepActiveRideStatus()
                },
                onCancelActiveRide = {
                    viewModel.cancelActiveRide()
                },
                onSimulateIncomingRequest = {
                    viewModel.triggerSimulatedDriverIncomingTrip()
                },
                onSwitchToPassenger = {
                    viewModel.switchRole(UserRole.PASSENGER)
                    navController.navigate(NovaDestinations.PASSENGER_HOME) {
                        popUpTo(NovaDestinations.DRIVER_HOME) { inclusive = true }
                    }
                },
                onLogout = {
                    viewModel.logout()
                    navController.navigate(NovaDestinations.LOGIN) {
                        popUpTo(NovaDestinations.DRIVER_HOME) { inclusive = true }
                    }
                }
            )
        }
    }
}
