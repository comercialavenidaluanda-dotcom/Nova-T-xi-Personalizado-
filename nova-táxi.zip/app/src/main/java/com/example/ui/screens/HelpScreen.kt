package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.ui.theme.NovaBorderLight
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaWhite

@Composable
fun HelpScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NovaIce)
            .statusBarsPadding()
            .testTag("help_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            NovaBadge(text = "SUPORTE E AJUDA", accentColor = NovaOrange)
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Central de Ajuda NOVA",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 24.sp),
                fontWeight = FontWeight.Black,
                color = NovaCharcoal
            )
            Text(
                text = "Estamos aqui para garantir viagens seguras e confiáveis em Luanda.",
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextSecondary
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Direct Contact Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, shape = RoundedCornerShape(20.dp), spotColor = NovaOrange.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(20.dp),
                color = NovaWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Contactos Imediatos",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NovaCharcoal
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    HelpContactItem(
                        icon = Icons.Default.HeadsetMic,
                        title = "Linha de Apoio ao Cliente",
                        detail = "+244 923 000 000 (24h/7d)",
                        accentColor = NovaOrange
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = NovaBorderLight)

                    HelpContactItem(
                        icon = Icons.Default.Email,
                        title = "E-mail de Suporte",
                        detail = "suporte@novataxi.ao",
                        accentColor = NovaPurple
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = NovaBorderLight)

                    HelpContactItem(
                        icon = Icons.Default.Shield,
                        title = "Central de Emergência e Segurança",
                        detail = "Botão de pânico e equipa SOS em tempo real",
                        accentColor = NovaOrange
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Perguntas Frequentes (FAQ)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = NovaCharcoal
            )
            Spacer(modifier = Modifier.height(10.dp))

            val faqs = listOf(
                "Como funciona o pagamento em dinheiro (Cash)?" to "O pagamento é efetuado diretamente ao motorista no final da viagem. O valor exato é calculado e exibido no aplicativo.",
                "Como o motorista é atribuído à minha viagem?" to "O sistema inteligente da NOVA encontra o motorista disponível mais próximo do seu ponto de recolha.",
                "O que fazer se esquecer um objeto no carro?" to "Pode contactar imediatamente o motorista através do histórico de corridas ou ligar para a nossa Linha de Apoio.",
                "Como me tornar motorista parceiro NOVA?" to "Basta aceder ao menu de cadastro, selecionar 'Motorista', submeter a sua carta de condução e os documentos da sua viatura."
            )

            faqs.forEach { (question, answer) ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = NovaWhite,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaBorderLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = question,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NovaCharcoal,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = answer,
                            style = MaterialTheme.typography.bodyMedium,
                            color = NovaTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun HelpContactItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    detail: String,
    accentColor: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = NovaCharcoal)
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = NovaTextSecondary)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NovaTextSecondary)
    }
}
