package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaLightCard
import com.example.data.model.LocationPoint
import com.example.data.model.LuandaLocations
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun FavoritesScreen(
    onSelectLocation: (LocationPoint) -> Unit,
    modifier: Modifier = Modifier
) {
    val favorites = listOf(
        Pair(LuandaLocations.KILAMBA, Icons.Default.Home),
        Pair(LuandaLocations.TALATONA, Icons.Default.Business),
        Pair(LuandaLocations.AEROPORTO, Icons.Default.Flight),
        Pair(LuandaLocations.MARGINAL, Icons.Default.Star),
        Pair(LuandaLocations.ILHA, Icons.Default.Favorite),
        Pair(LuandaLocations.MUTAMBA, Icons.Default.LocationOn)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NovaIce)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .testTag("favorites_screen")
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Locais Favoritos",
                    style = MaterialTheme.typography.headlineLarge,
                    color = NovaCharcoal,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Acesso rápido aos seus destinos habituais",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaTextSecondary
                )
            }
            NovaBadge(text = "LUANDA", accentColor = NovaCoral)
        }

        Spacer(modifier = Modifier.height(18.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(favorites) { (loc, icon) ->
                NovaLightCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectLocation(loc) }
                        .testTag("favorite_${loc.id}"),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(NovaOrange.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = NovaOrange,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = loc.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NovaCharcoal
                            )
                            Text(
                                text = loc.address,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NovaTextSecondary
                            )
                        }
                        NovaBadge(text = "ESCOLHER", accentColor = NovaOrange)
                    }
                }
            }
        }
    }
}
