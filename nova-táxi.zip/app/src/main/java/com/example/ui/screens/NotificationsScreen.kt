package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.NovaBadge
import com.example.core.designsystem.NovaLightCard
import com.example.ui.theme.NovaCharcoal
import com.example.ui.theme.NovaCoral
import com.example.ui.theme.NovaIce
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

data class NovaNotification(
    val id: String,
    val title: String,
    val message: String,
    val timeAgo: String,
    val icon: ImageVector,
    val accentColor: androidx.compose.ui.graphics.Color
)

@Composable
fun NotificationsScreen(modifier: Modifier = Modifier) {
    val notifications = listOf(
        NovaNotification(
            id = "notif_1",
            title = "Promoção de Fim de Semana",
            message = "Ganhe 20% de desconto em viagens COOL para a Ilha de Luanda com Multicaixa Express.",
            timeAgo = "Há 10 min",
            icon = Icons.Default.Discount,
            accentColor = NovaOrange
        ),
        NovaNotification(
            id = "notif_2",
            title = "Corrida Concluída",
            message = "A sua viagem de Talatona para a Marginal foi finalizada com sucesso. Obrigado!",
            timeAgo = "Hoje, 10:45",
            icon = Icons.Default.CheckCircle,
            accentColor = NovaLime
        ),
        NovaNotification(
            id = "notif_3",
            title = "Segurança NOVA em Luanda",
            message = "Partilhe o seu trajeto em tempo real com amigos ou familiares em qualquer viagem.",
            timeAgo = "Ontem",
            icon = Icons.Default.Security,
            accentColor = NovaPurple
        ),
        NovaNotification(
            id = "notif_4",
            title = "Nova Categoria: NOVA BIKE",
            message = "Chegue mais rápido ao seu destino e fuja ao trânsito com motoristas certificados.",
            timeAgo = "Há 2 dias",
            icon = Icons.Default.LocalTaxi,
            accentColor = NovaSun
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NovaIce)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .testTag("notifications_screen")
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Notificações",
                    style = MaterialTheme.typography.headlineLarge,
                    color = NovaCharcoal,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Atualizações das suas corridas e ofertas",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaTextSecondary
                )
            }
            NovaBadge(text = "4 NOVAS", accentColor = NovaOrange)
        }

        Spacer(modifier = Modifier.height(18.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(notifications) { notif ->
                NovaLightCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(notif.accentColor.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = notif.icon,
                                contentDescription = null,
                                tint = notif.accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = notif.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaCharcoal
                                )
                                Text(
                                    text = notif.timeAgo,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NovaTextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = notif.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NovaTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
