package com.example.data.model

enum class UserRole(val label: String, val badgeTitle: String) {
    PASSENGER(label = "Passageiro", badgeTitle = "PERFIL PASSAGEIRO"),
    DRIVER(label = "Motorista", badgeTitle = "PERFIL MOTORISTA")
}

data class VehicleInfo(
    val brand: String,
    val model: String,
    val licensePlate: String,
    val color: String,
    val year: Int,
    val category: String = "COOL"
)

data class DriverProfile(
    val documentNumber: String,
    val driverLicenseNumber: String,
    val vehicle: VehicleInfo? = null,
    val rating: Double = 5.0,
    val totalRides: Int = 0,
    val isOnline: Boolean = true,
    val earningsTodayAoa: Long = 0L,
    val isVerified: Boolean = true,
    val isAvailableForRide: Boolean = true
)

data class User(
    val id: String,
    val name: String,
    val phone: String,
    val email: String? = null,
    val role: UserRole = UserRole.PASSENGER,
    val avatarUrl: String? = null,
    val driverProfile: DriverProfile? = null
)
