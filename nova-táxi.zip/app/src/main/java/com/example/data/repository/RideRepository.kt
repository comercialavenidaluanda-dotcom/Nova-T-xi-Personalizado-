package com.example.data.repository

import com.example.core.network.DriverLocationDto
import com.example.core.network.NovaAcceptRidePayload
import com.example.core.network.NovaCalculateFarePayload
import com.example.core.network.NovaRecordPaymentPayload
import com.example.core.network.NovaUpdateStatusPayload
import com.example.core.network.PaymentDto
import com.example.core.network.RatingDto
import com.example.core.network.RideDto
import com.example.core.network.RideRequestDto
import com.example.core.network.SupabaseNetworkClient
import com.example.data.model.ActiveDriver
import com.example.data.model.BackendCommission
import com.example.data.model.LocationPoint
import com.example.data.model.PaymentMethod
import com.example.data.model.RideCategory
import com.example.data.model.RideRequest
import com.example.data.model.RideStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

interface RideRepository {
    val activeRide: StateFlow<RideRequest?>
    val nearbyDrivers: StateFlow<List<ActiveDriver>>
    val incomingDriverRequest: StateFlow<RideRequest?>
    val rideHistory: StateFlow<List<RideRequest>>
    val isRealBackendConnected: Boolean

    suspend fun requestRide(
        passengerId: String,
        passengerName: String,
        passengerPhone: String,
        pickup: LocationPoint,
        destination: LocationPoint,
        category: RideCategory,
        paymentMethod: PaymentMethod
    ): Result<RideRequest>

    suspend fun cancelActiveRide(): Result<Unit>
    suspend fun advanceRideStatus(userId: String): Result<RideStatus>
    suspend fun submitRating(score: Int, comment: String): Result<Unit>
    suspend fun driverAcceptIncoming(requestId: String, driverId: String): Result<Unit>
    suspend fun driverRejectIncoming(requestId: String): Result<Unit>
    suspend fun updateDriverGpsLocation(driverId: String, lat: Double, lng: Double, heading: Float)
    suspend fun refreshPendingRequestsForDriver()
    fun triggerSimulatedDriverIncomingTrip()
}

class RealSupabaseRideRepository(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) : RideRepository {

    private val _activeRide = MutableStateFlow<RideRequest?>(null)
    override val activeRide: StateFlow<RideRequest?> = _activeRide.asStateFlow()

    private val _nearbyDrivers = MutableStateFlow<List<ActiveDriver>>(emptyList())
    override val nearbyDrivers: StateFlow<List<ActiveDriver>> = _nearbyDrivers.asStateFlow()

    private val _incomingDriverRequest = MutableStateFlow<RideRequest?>(null)
    override val incomingDriverRequest: StateFlow<RideRequest?> = _incomingDriverRequest.asStateFlow()

    private val _rideHistory = MutableStateFlow<List<RideRequest>>(emptyList())
    override val rideHistory: StateFlow<List<RideRequest>> = _rideHistory.asStateFlow()

    private var _isRealBackendConnected: Boolean = false
    override val isRealBackendConnected: Boolean
        get() = _isRealBackendConnected

    init {
        // Poll real drivers and sync with Supabase
        scope.launch {
            while (isActive) {
                fetchRealDriverLocations()
                delay(10000)
            }
        }
    }

    private suspend fun fetchRealDriverLocations() = withContext(Dispatchers.IO) {
        try {
            val response = SupabaseNetworkClient.restApi.getDriverLocations()
            if (response.isSuccessful && response.body() != null) {
                _isRealBackendConnected = true
                val locList = response.body()!!
                val driverList = locList.map { loc ->
                    ActiveDriver(
                        id = loc.driverId,
                        name = "Motorista NOVA",
                        phone = "+244 923 000 000",
                        rating = 4.95,
                        totalTrips = 100,
                        vehicleModel = "Toyota",
                        vehiclePlate = "LD-00-00-AO",
                        vehicleColor = "Branco",
                        currentLat = loc.latitude,
                        currentLng = loc.longitude,
                        headingDegrees = loc.heading,
                        category = RideCategory.COOL
                    )
                }
                _nearbyDrivers.value = driverList
            }
        } catch (_: Exception) {}
    }

    override suspend fun updateDriverGpsLocation(
        driverId: String,
        lat: Double,
        lng: Double,
        heading: Float
    ): Unit = withContext(Dispatchers.IO) {
        try {
            SupabaseNetworkClient.restApi.upsertDriverLocation(
                DriverLocationDto(
                    driverId = driverId,
                    latitude = lat,
                    longitude = lng,
                    heading = heading
                )
            )
        } catch (_: Exception) {}
        Unit
    }

    override suspend fun requestRide(
        passengerId: String,
        passengerName: String,
        passengerPhone: String,
        pickup: LocationPoint,
        destination: LocationPoint,
        category: RideCategory,
        paymentMethod: PaymentMethod
    ): Result<RideRequest> = withContext(Dispatchers.IO) {
        val requestId = "req_" + UUID.randomUUID().toString().take(12)
        val approxDistanceKm = 7.5

        // Cálculo de tarifa e comissão 20% no backend Supabase
        var fareAoa = category.basePriceAoa
        var commissionAoa = (fareAoa * 20L) / 100L
        var driverNetAoa = fareAoa - commissionAoa

        try {
            val calcResponse = SupabaseNetworkClient.restApi.rpcCalculateFareAndCommission(
                NovaCalculateFarePayload(
                    category = category.name,
                    distanceKm = approxDistanceKm
                )
            )
            if (calcResponse.isSuccessful && calcResponse.body() != null) {
                val calc = calcResponse.body()!!
                fareAoa = calc.fareAmountAoa
                commissionAoa = calc.novaCommissionAoa
                driverNetAoa = calc.driverNetAoa
            }
        } catch (_: Exception) {}

        val commission = BackendCommission(
            ratePercentage = 20.0,
            totalFareAoa = fareAoa,
            novaAmountAoa = commissionAoa,
            driverNetAoa = driverNetAoa
        )

        val rideRequestDto = RideRequestDto(
            id = requestId,
            passengerId = passengerId,
            passengerName = passengerName,
            passengerPhone = passengerPhone,
            pickupName = pickup.name,
            pickupLat = pickup.latitude,
            pickupLng = pickup.longitude,
            destName = destination.name,
            destLat = destination.latitude,
            destLng = destination.longitude,
            category = category.name,
            estimatedPriceAoa = fareAoa,
            distanceKm = approxDistanceKm,
            paymentMethod = paymentMethod.code,
            status = RideStatus.REQUESTED.name
        )

        try {
            val response = SupabaseNetworkClient.restApi.createRideRequest(rideRequestDto)
            if (response.isSuccessful) {
                _isRealBackendConnected = true
            }
        } catch (e: Exception) {
            // Em caso de erro de rede, mantemos a requisição para não travar o passageiro
        }

        val newRide = RideRequest(
            id = requestId,
            passengerId = passengerId,
            passengerName = passengerName,
            passengerPhone = passengerPhone,
            pickup = pickup,
            destination = destination,
            category = category,
            paymentMethod = paymentMethod,
            priceAoa = fareAoa,
            status = RideStatus.SEARCHING,
            driver = null,
            etaMinutes = category.estimatedMinutes,
            distanceKm = approxDistanceKm,
            commission = commission
        )
        _activeRide.value = newRide

        // Iniciar polling em segundo plano para sincronizar estado real do pedido no Supabase
        scope.launch {
            pollRideStatusFromSupabase(requestId)
        }

        return@withContext Result.success(newRide)
    }

    private suspend fun pollRideStatusFromSupabase(requestId: String) {
        var attempts = 0
        while (attempts < 60) {
            delay(3000)
            attempts++
            val current = _activeRide.value ?: break
            if (current.id != requestId || current.status.isFinal) break

            try {
                // Verificar se a corrida foi aceite na tabela rides
                val rideRes = SupabaseNetworkClient.restApi.getRideByRequestId("eq.$requestId")
                val rideList = rideRes.body()
                if (!rideList.isNullOrEmpty()) {
                    val realRide = rideList.first()
                    val newStatus = RideStatus.fromBackendString(realRide.status)
                    if (newStatus != current.status) {
                        _activeRide.value = current.copy(
                            status = newStatus,
                            priceAoa = realRide.fareAmountAoa
                        )
                    }
                    if (newStatus.isFinal) break
                    continue
                }

                // Verificar estado em ride_requests
                val reqRes = SupabaseNetworkClient.restApi.getRideRequest("eq.$requestId")
                val reqList = reqRes.body()
                if (!reqList.isNullOrEmpty()) {
                    val reqData = reqList.first()
                    val backendStatus = RideStatus.fromBackendString(reqData.status)
                    if (backendStatus != current.status) {
                        _activeRide.value = current.copy(status = backendStatus)
                    }
                    if (backendStatus.isFinal) break
                }
            } catch (_: Exception) {}
        }
    }

    override suspend fun cancelActiveRide(): Result<Unit> = withContext(Dispatchers.IO) {
        val current = _activeRide.value ?: return@withContext Result.success(Unit)
        try {
            SupabaseNetworkClient.restApi.rpcUpdateRideStatus(
                NovaUpdateStatusPayload(
                    rideId = current.id,
                    status = RideStatus.CANCELLED.name,
                    userId = current.passengerId
                )
            )
        } catch (_: Exception) {
            try {
                SupabaseNetworkClient.restApi.updateRideRequestStatus(
                    "eq.${current.id}",
                    mapOf("status" to RideStatus.CANCELLED.name)
                )
            } catch (_: Exception) {}
        }

        _activeRide.value = null
        return@withContext Result.success(Unit)
    }

    override suspend fun advanceRideStatus(userId: String): Result<RideStatus> = withContext(Dispatchers.IO) {
        val current = _activeRide.value ?: return@withContext Result.failure(IllegalStateException("Nenhuma corrida ativa"))

        val nextStatus = when (current.status) {
            RideStatus.REQUESTED -> RideStatus.SEARCHING
            RideStatus.SEARCHING -> RideStatus.ACCEPTED
            RideStatus.ACCEPTED -> RideStatus.ARRIVED
            RideStatus.ARRIVED -> RideStatus.IN_PROGRESS
            RideStatus.IN_PROGRESS -> RideStatus.COMPLETED
            RideStatus.COMPLETED -> RideStatus.COMPLETED
            RideStatus.CANCELLED -> RideStatus.CANCELLED
        }

        // Persistir no Supabase através do RPC seguro
        try {
            SupabaseNetworkClient.restApi.rpcUpdateRideStatus(
                NovaUpdateStatusPayload(
                    rideId = current.id,
                    status = nextStatus.name,
                    userId = userId
                )
            )

            // Quando a viagem é concluída, registar pagamento real em CASH no Supabase
            if (nextStatus == RideStatus.COMPLETED) {
                SupabaseNetworkClient.restApi.rpcRecordCashPayment(
                    NovaRecordPaymentPayload(
                        rideId = current.id,
                        amountAoa = current.priceAoa
                    )
                )
            }
        } catch (_: Exception) {
            try {
                SupabaseNetworkClient.restApi.updateRideRequestStatus(
                    "eq.${current.id}",
                    mapOf("status" to nextStatus.name)
                )
            } catch (_: Exception) {}
        }

        val updated = current.copy(status = nextStatus)
        _activeRide.value = updated

        if (nextStatus == RideStatus.COMPLETED) {
            _rideHistory.value = listOf(updated) + _rideHistory.value
        }

        return@withContext Result.success(nextStatus)
    }

    override suspend fun submitRating(score: Int, comment: String): Result<Unit> = withContext(Dispatchers.IO) {
        val current = _activeRide.value ?: return@withContext Result.success(Unit)

        try {
            SupabaseNetworkClient.restApi.recordRating(
                RatingDto(
                    id = "rate_" + UUID.randomUUID().toString().take(12),
                    rideId = current.id,
                    fromUserId = current.passengerId,
                    toUserId = current.driver?.id ?: current.passengerId,
                    score = score,
                    comment = comment
                )
            )
        } catch (_: Exception) {}

        val completed = current.copy(
            ratingScore = score,
            ratingComment = comment
        )
        _rideHistory.value = listOf(completed) + _rideHistory.value.filter { it.id != completed.id }
        _activeRide.value = null

        return@withContext Result.success(Unit)
    }

    override suspend fun driverAcceptIncoming(requestId: String, driverId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val incoming = _incomingDriverRequest.value ?: return@withContext Result.failure(IllegalStateException("Pedido não encontrado ou expirado"))

        try {
            // Chamada RPC atómica com proteção contra dupla aceitação
            val rpcResponse = SupabaseNetworkClient.restApi.rpcAcceptRide(
                NovaAcceptRidePayload(
                    requestId = requestId,
                    driverId = driverId
                )
            )

            if (!rpcResponse.isSuccessful || rpcResponse.body()?.success != true) {
                val errorMsg = rpcResponse.errorBody()?.string() ?: "A corrida já foi aceite por outro motorista ou cancelada."
                _incomingDriverRequest.value = null
                return@withContext Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            // Fallback para update direto em ride_requests se o RPC ainda estiver em propagação de schema
            try {
                SupabaseNetworkClient.restApi.updateRideRequestStatus(
                    "eq.$requestId",
                    mapOf("status" to "ACCEPTED", "driver_id" to driverId)
                )
            } catch (_: Exception) {}
        }

        _incomingDriverRequest.value = null
        val acceptedRide = incoming.copy(
            status = RideStatus.ACCEPTED
        )
        _activeRide.value = acceptedRide
        return@withContext Result.success(Unit)
    }

    override suspend fun driverRejectIncoming(requestId: String): Result<Unit> = withContext(Dispatchers.IO) {
        _incomingDriverRequest.value = null
        return@withContext Result.success(Unit)
    }

    override suspend fun refreshPendingRequestsForDriver() = withContext(Dispatchers.IO) {
        try {
            val response = SupabaseNetworkClient.restApi.getPendingRideRequests(
                statusFilter = "eq.REQUESTED",
                order = "created_at.desc"
            )
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val firstReq = response.body()!!.first()
                val category = try { RideCategory.valueOf(firstReq.category) } catch (_: Exception) { RideCategory.COOL }
                val payment = try { PaymentMethod.valueOf(firstReq.paymentMethod) } catch (_: Exception) { PaymentMethod.CASH }

                val incoming = RideRequest(
                    id = firstReq.id,
                    passengerId = firstReq.passengerId,
                    passengerName = firstReq.passengerName,
                    passengerPhone = firstReq.passengerPhone,
                    pickup = LocationPoint(
                        id = "loc_pickup",
                        name = firstReq.pickupName,
                        address = firstReq.pickupName,
                        latitude = firstReq.pickupLat,
                        longitude = firstReq.pickupLng
                    ),
                    destination = LocationPoint(
                        id = "loc_dest",
                        name = firstReq.destName,
                        address = firstReq.destName,
                        latitude = firstReq.destLat,
                        longitude = firstReq.destLng
                    ),
                    category = category,
                    paymentMethod = payment,
                    priceAoa = firstReq.estimatedPriceAoa,
                    status = RideStatus.REQUESTED,
                    distanceKm = firstReq.distanceKm,
                    etaMinutes = category.estimatedMinutes
                )
                _incomingDriverRequest.value = incoming
            }
        } catch (_: Exception) {}
    }

    override fun triggerSimulatedDriverIncomingTrip() {
        scope.launch {
            refreshPendingRequestsForDriver()
        }
    }
}
