package com.example.data.repository

import com.example.core.network.DriverDto
import com.example.core.network.ProfileDto
import com.example.core.network.SupabaseNetworkClient
import com.example.core.network.SupabaseSignInPayload
import com.example.core.network.SupabaseSignUpPayload
import com.example.core.network.VehicleDto
import com.example.data.model.DriverProfile
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.data.model.VehicleInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

interface AuthRepository {
    val currentUser: StateFlow<User?>
    val isRealBackendConnected: Boolean
    suspend fun login(identifier: String, password: String): Result<User>
    suspend fun registerPassenger(name: String, phone: String, email: String?, password: String): Result<User>
    suspend fun registerDriver(
        name: String,
        phone: String,
        email: String,
        password: String,
        documentNumber: String,
        licenseNumber: String,
        vehicleBrand: String,
        vehicleModel: String,
        licensePlate: String,
        vehicleColor: String,
        vehicleYear: Int
    ): Result<User>
    suspend fun switchRole(newRole: UserRole)
    suspend fun toggleDriverOnline(): Boolean
    suspend fun logout()
}

class RealSupabaseAuthRepository : AuthRepository {
    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private var _isRealBackendConnected = false
    override val isRealBackendConnected: Boolean
        get() = _isRealBackendConnected

    override suspend fun login(identifier: String, password: String): Result<User> = withContext(Dispatchers.IO) {
        if (identifier.isBlank() || password.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Insira o seu contacto/e-mail e a palavra-passe."))
        }

        val authEmail = if (identifier.contains("@")) {
            identifier.trim().lowercase()
        } else {
            val cleanPhone = identifier.replace(" ", "").replace("+", "").replace("-", "")
            "user_$cleanPhone@novataxi.ao"
        }

        try {
            val response = SupabaseNetworkClient.authApi.signIn(
                SupabaseSignInPayload(email = authEmail, password = password)
            )

            if (response.isSuccessful && response.body() != null) {
                val session = response.body()!!
                SupabaseNetworkClient.setAuthToken(session.accessToken)
                _isRealBackendConnected = true

                val user = fetchProfileFromSupabase(session.user.id, authEmail, session.user.phone ?: identifier)
                _currentUser.value = user
                return@withContext Result.success(user)
            } else {
                val errorBody = response.errorBody()?.string() ?: "Credenciais incorretas"
                return@withContext Result.failure(Exception("Falha na autenticação Supabase (${response.code()}): $errorBody"))
            }
        } catch (e: Exception) {
            return@withContext Result.failure(Exception("Erro de ligação ao Supabase: ${e.localizedMessage ?: e.message}"))
        }
    }

    override suspend fun registerPassenger(
        name: String,
        phone: String,
        email: String?,
        password: String
    ): Result<User> = withContext(Dispatchers.IO) {
        if (name.isBlank() || phone.isBlank() || password.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("Nome, telefone e palavra-passe mínima de 6 caracteres são obrigatórios."))
        }

        val authEmail = if (!email.isNullOrBlank() && email.contains("@")) {
            email.trim().lowercase()
        } else {
            val cleanPhone = phone.replace(" ", "").replace("+", "").replace("-", "")
            "pax_$cleanPhone@novataxi.ao"
        }

        try {
            val signUpResponse = SupabaseNetworkClient.authApi.signUp(
                SupabaseSignUpPayload(
                    email = authEmail,
                    password = password,
                    phone = phone,
                    data = mapOf("full_name" to name.trim(), "role" to "passenger")
                )
            )

            if (!signUpResponse.isSuccessful || signUpResponse.body() == null) {
                val errorBody = signUpResponse.errorBody()?.string() ?: "Erro ao registar conta"
                return@withContext Result.failure(Exception("Erro no registo Supabase: $errorBody"))
            }

            val session = signUpResponse.body()!!
            val userId = session.user.id
            if (session.accessToken.isNotBlank()) {
                SupabaseNetworkClient.setAuthToken(session.accessToken)
                _isRealBackendConnected = true
            }

            // Inserir perfil na tabela pública profiles
            try {
                SupabaseNetworkClient.restApi.insertProfile(
                    ProfileDto(
                        id = userId,
                        fullName = name.trim(),
                        phone = phone.trim(),
                        email = authEmail,
                        role = "passenger"
                    )
                )
            } catch (_: Exception) {}

            val user = User(
                id = userId,
                name = name.trim(),
                phone = phone.trim(),
                email = authEmail,
                role = UserRole.PASSENGER
            )
            _currentUser.value = user
            return@withContext Result.success(user)
        } catch (e: Exception) {
            return@withContext Result.failure(Exception("Falha ao comunicar com Supabase: ${e.localizedMessage ?: e.message}"))
        }
    }

    override suspend fun registerDriver(
        name: String,
        phone: String,
        email: String,
        password: String,
        documentNumber: String,
        licenseNumber: String,
        vehicleBrand: String,
        vehicleModel: String,
        licensePlate: String,
        vehicleColor: String,
        vehicleYear: Int
    ): Result<User> = withContext(Dispatchers.IO) {
        if (name.isBlank() || phone.isBlank() || email.isBlank() || password.length < 6 ||
            documentNumber.isBlank() || licenseNumber.isBlank() || licensePlate.isBlank()
        ) {
            return@withContext Result.failure(IllegalArgumentException("Todos os dados do motorista, documentação e veículo são obrigatórios."))
        }

        val authEmail = email.trim().lowercase()

        try {
            val signUpResponse = SupabaseNetworkClient.authApi.signUp(
                SupabaseSignUpPayload(
                    email = authEmail,
                    password = password,
                    phone = phone,
                    data = mapOf("full_name" to name.trim(), "role" to "driver")
                )
            )

            if (!signUpResponse.isSuccessful || signUpResponse.body() == null) {
                val errorBody = signUpResponse.errorBody()?.string() ?: "Erro ao criar conta de motorista"
                return@withContext Result.failure(Exception("Erro no registo Supabase: $errorBody"))
            }

            val session = signUpResponse.body()!!
            val userId = session.user.id
            if (session.accessToken.isNotBlank()) {
                SupabaseNetworkClient.setAuthToken(session.accessToken)
                _isRealBackendConnected = true
            }

            // Inserir perfil, motorista e veículo no Supabase
            try {
                SupabaseNetworkClient.restApi.insertProfile(
                    ProfileDto(
                        id = userId,
                        fullName = name.trim(),
                        phone = phone.trim(),
                        email = authEmail,
                        role = "driver"
                    )
                )
                SupabaseNetworkClient.restApi.insertDriver(
                    DriverDto(
                        id = userId,
                        documentNumber = documentNumber.trim().uppercase(),
                        licenseNumber = licenseNumber.trim().uppercase(),
                        isOnline = true,
                        isVerified = true
                    )
                )
                SupabaseNetworkClient.restApi.insertVehicle(
                    VehicleDto(
                        driverId = userId,
                        brand = vehicleBrand.trim(),
                        model = vehicleModel.trim(),
                        licensePlate = licensePlate.trim().uppercase(),
                        color = vehicleColor.trim(),
                        year = vehicleYear,
                        category = "COOL"
                    )
                )
            } catch (_: Exception) {}

            val driverProfile = DriverProfile(
                documentNumber = documentNumber.trim().uppercase(),
                driverLicenseNumber = licenseNumber.trim().uppercase(),
                vehicle = VehicleInfo(
                    brand = vehicleBrand.trim(),
                    model = vehicleModel.trim(),
                    licensePlate = licensePlate.trim().uppercase(),
                    color = vehicleColor.trim(),
                    year = vehicleYear,
                    category = "COOL"
                ),
                rating = 5.0,
                totalRides = 0,
                isOnline = true,
                earningsTodayAoa = 0L,
                isVerified = true
            )

            val user = User(
                id = userId,
                name = name.trim(),
                phone = phone.trim(),
                email = authEmail,
                role = UserRole.DRIVER,
                driverProfile = driverProfile
            )
            _currentUser.value = user
            return@withContext Result.success(user)
        } catch (e: Exception) {
            return@withContext Result.failure(Exception("Falha ao registar motorista no Supabase: ${e.localizedMessage ?: e.message}"))
        }
    }

    private suspend fun fetchProfileFromSupabase(userId: String, email: String, phone: String): User {
        try {
            val profResponse = SupabaseNetworkClient.restApi.getProfile("eq.$userId")
            val profile = profResponse.body()?.firstOrNull()

            val role = if (profile?.role == "driver") UserRole.DRIVER else UserRole.PASSENGER
            var driverProfile: DriverProfile? = null

            if (role == UserRole.DRIVER) {
                val driverResponse = SupabaseNetworkClient.restApi.getDriver("eq.$userId")
                val driverData = driverResponse.body()?.firstOrNull()

                val vehicleResponse = SupabaseNetworkClient.restApi.getVehicleForDriver("eq.$userId")
                val vehicleData = vehicleResponse.body()?.firstOrNull()

                val vehicleInfo = if (vehicleData != null) {
                    VehicleInfo(
                        brand = vehicleData.brand,
                        model = vehicleData.model,
                        licensePlate = vehicleData.licensePlate,
                        color = vehicleData.color,
                        year = vehicleData.year,
                        category = vehicleData.category
                    )
                } else null

                driverProfile = DriverProfile(
                    documentNumber = driverData?.documentNumber ?: "",
                    driverLicenseNumber = driverData?.licenseNumber ?: "",
                    vehicle = vehicleInfo,
                    rating = profile?.rating ?: 5.0,
                    totalRides = driverData?.totalRides ?: 0,
                    isOnline = driverData?.isOnline ?: true,
                    earningsTodayAoa = driverData?.earningsTodayAoa ?: 0L,
                    isVerified = driverData?.isVerified ?: true
                )
            }

            return User(
                id = userId,
                name = profile?.fullName ?: email.substringBefore("@").replace(".", " ").capitalize(),
                phone = profile?.phone ?: phone,
                email = email,
                role = role,
                driverProfile = driverProfile
            )
        } catch (e: Exception) {
            return User(
                id = userId,
                name = email.substringBefore("@").replace(".", " ").capitalize(),
                phone = phone,
                email = email,
                role = UserRole.PASSENGER
            )
        }
    }

    override suspend fun switchRole(newRole: UserRole) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        val updated = if (newRole == UserRole.DRIVER) {
            current.copy(
                role = UserRole.DRIVER,
                driverProfile = current.driverProfile ?: DriverProfile(
                    documentNumber = "",
                    driverLicenseNumber = "",
                    vehicle = null,
                    rating = 5.0,
                    totalRides = 0,
                    isOnline = true,
                    earningsTodayAoa = 0L,
                    isVerified = true
                )
            )
        } else {
            current.copy(role = UserRole.PASSENGER)
        }
        _currentUser.value = updated

        try {
            SupabaseNetworkClient.restApi.insertProfile(
                ProfileDto(
                    id = current.id,
                    fullName = current.name,
                    phone = current.phone,
                    email = current.email,
                    role = if (newRole == UserRole.DRIVER) "driver" else "passenger"
                )
            )
        } catch (_: Exception) {}
    }

    override suspend fun toggleDriverOnline(): Boolean = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext false
        val profile = current.driverProfile ?: return@withContext false
        val newStatus = !profile.isOnline

        _currentUser.value = current.copy(
            driverProfile = profile.copy(isOnline = newStatus)
        )

        try {
            SupabaseNetworkClient.restApi.updateDriverOnlineStatus(
                "eq.${current.id}",
                mapOf("is_online" to newStatus)
            )
        } catch (_: Exception) {}

        return@withContext newStatus
    }

    override suspend fun logout() = withContext(Dispatchers.IO) {
        SupabaseNetworkClient.setAuthToken(null)
        _currentUser.value = null
    }
}
