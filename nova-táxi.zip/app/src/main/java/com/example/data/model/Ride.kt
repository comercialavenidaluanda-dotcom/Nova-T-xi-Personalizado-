package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.NovaLime
import com.example.ui.theme.NovaOrange
import com.example.ui.theme.NovaPurple
import com.example.ui.theme.NovaSun

data class LocationPoint(
    val id: String,
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val isFavorite: Boolean = false,
    val shortcutType: String? = null
)

enum class RideCategory(
    val title: String,
    val subtitle: String,
    val basePriceAoa: Long,
    val estimatedMinutes: Int,
    val accentColor: Color,
    val badgeText: String,
    val capacity: String
) {
    ECONOMICA(
        title = "ECONÓMICA",
        subtitle = "Viagem rápida e mais acessível",
        basePriceAoa = 1500L,
        estimatedMinutes = 4,
        accentColor = NovaSun,
        badgeText = "SUPER ECONÓMICO",
        capacity = "4 pessoas • Acessível"
    ),
    COOL(
        title = "COOL",
        subtitle = "Viagem económica e confortável",
        basePriceAoa = 2100L,
        estimatedMinutes = 3,
        accentColor = NovaOrange,
        badgeText = "MAIS POPULAR",
        capacity = "4 pessoas • AC"
    ),
    EXECUTIVO(
        title = "EXECUTIVO",
        subtitle = "Mais conforto e experiência premium",
        basePriceAoa = 4200L,
        estimatedMinutes = 5,
        accentColor = NovaPurple,
        badgeText = "PREMIUM",
        capacity = "Sedan novo • Espaço"
    ),
    VIP(
        title = "VIP",
        subtitle = "Experiência exclusiva topo de gama",
        basePriceAoa = 6500L,
        estimatedMinutes = 6,
        accentColor = NovaSun,
        badgeText = "EXCLUSIVO",
        capacity = "SUV Luxo • Motorista VIP"
    ),
    BIKE(
        title = "BIKE",
        subtitle = "Viagens rápidas e económicas",
        basePriceAoa = 1200L,
        estimatedMinutes = 2,
        accentColor = NovaLime,
        badgeText = "SUPER RÁPIDO",
        capacity = "1 passageiro • Capacete"
    )
}

enum class PaymentMethod(val label: String, val shortName: String, val code: String, val isProductionReady: Boolean) {
    CASH("Dinheiro em Mãos (Cash)", "Cash", "CASH", isProductionReady = true),
    MULTICAIXA_EXPRESS("Multicaixa Express (Em Homologação)", "MCX", "MCX", isProductionReady = false),
    REFERENCIA("Referência Multicaixa (Em Homologação)", "Referência", "REF", isProductionReady = false),
    IBAN("Transferência IBAN (Em Homologação)", "IBAN", "IBAN", isProductionReady = false),
    KWIK("KWiK Instantâneo (Em Homologação)", "KWiK", "KWIK", isProductionReady = false)
}

/**
 * Backend-controlled Ride State Machine (Supabase real-time sync)
 */
enum class RideStatus(
    val stepIndex: Int,
    val displayTitle: String,
    val description: String,
    val isFinal: Boolean = false
) {
    REQUESTED(1, "Pedido criado", "Aguardando confirmação do pedido"),
    SEARCHING(2, "A procurar motorista", "NOVA está a procurar o motorista mais próximo"),
    ACCEPTED(3, "Motorista a caminho", "Motorista aceitou e prepara a viagem"),
    ARRIVED(4, "Motorista no local", "Motorista no ponto de recolha"),
    IN_PROGRESS(5, "Em viagem", "Viagem em curso até ao destino"),
    COMPLETED(6, "Viagem concluída", "Chegámos ao seu destino!", isFinal = true),
    CANCELLED(7, "Corrida cancelada", "A corrida foi cancelada", isFinal = true);

    val isAcceptedOrBeyond: Boolean
        get() = this in listOf(ACCEPTED, ARRIVED, IN_PROGRESS, COMPLETED)

    companion object {
        fun fromBackendString(raw: String): RideStatus {
            return when (raw.uppercase()) {
                "REQUESTED" -> REQUESTED
                "SEARCHING" -> SEARCHING
                "DISPATCHED", "ACCEPTED", "DRIVER_ACCEPTED", "DRIVER_ASSIGNED", "DRIVER_ARRIVING", "DRIVER_ON_WAY" -> ACCEPTED
                "ARRIVED", "DRIVER_ARRIVED" -> ARRIVED
                "IN_PROGRESS", "TRIP_STARTED" -> IN_PROGRESS
                "COMPLETED", "TRIP_COMPLETED" -> COMPLETED
                "CANCELLED", "EXPIRED" -> CANCELLED
                else -> REQUESTED
            }
        }
    }
}

data class ActiveDriver(
    val id: String,
    val name: String,
    val phone: String,
    val rating: Double,
    val totalTrips: Int,
    val vehicleModel: String,
    val vehiclePlate: String,
    val vehicleColor: String,
    val currentLat: Double,
    val currentLng: Double,
    val headingDegrees: Float = 0f,
    val category: RideCategory = RideCategory.COOL
)

data class BackendCommission(
    val ratePercentage: Double = 20.0,
    val totalFareAoa: Long,
    val novaAmountAoa: Long = (totalFareAoa * 20L) / 100L,
    val driverNetAoa: Long = totalFareAoa - ((totalFareAoa * 20L) / 100L)
)

data class BackendFareCalculation(
    val category: String,
    val distanceKm: Double,
    val fareAmountAoa: Long,
    val novaCommissionAoa: Long,
    val driverNetAoa: Long,
    val commissionRate: Double = 0.20
)

data class RideRequest(
    val id: String,
    val passengerId: String,
    val passengerName: String,
    val passengerPhone: String,
    val pickup: LocationPoint,
    val destination: LocationPoint,
    val category: RideCategory,
    val paymentMethod: PaymentMethod,
    val priceAoa: Long,
    val status: RideStatus,
    val driver: ActiveDriver? = null,
    val etaMinutes: Int = 3,
    val distanceKm: Double = 6.8,
    val commission: BackendCommission = BackendCommission(totalFareAoa = priceAoa),
    val ratingScore: Int = 5,
    val ratingComment: String = ""
)

object LuandaLocations {
    val MARGINAL = LocationPoint(
        id = "loc_1",
        name = "Marginal de Luanda",
        address = "Avenida 4 de Fevereiro, Luanda",
        latitude = -8.8091,
        longitude = 13.2384,
        isFavorite = true,
        shortcutType = "FAVORITO"
    )
    val AEROPORTO = LocationPoint(
        id = "loc_2",
        name = "Aeroporto 4 de Fevereiro",
        address = "Avenida Deolinda Rodrigues, Luanda",
        latitude = -8.8584,
        longitude = 13.2312,
        isFavorite = true,
        shortcutType = "AEROPORTO"
    )
    val TALATONA = LocationPoint(
        id = "loc_3",
        name = "Talatona Shopping Avennida",
        address = "Via S8, Talatona, Luanda",
        latitude = -8.9168,
        longitude = 13.1843,
        isFavorite = true,
        shortcutType = "TRABALHO"
    )
    val KILAMBA = LocationPoint(
        id = "loc_4",
        name = "Centralidade do Kilamba",
        address = "Quarteirão K, Luanda Sul",
        latitude = -8.9950,
        longitude = 13.2560,
        isFavorite = true,
        shortcutType = "CASA"
    )
    val ILHA = LocationPoint(
        id = "loc_5",
        name = "Ilha do Cabo (Ponto Final)",
        address = "Avenida Murtala Mohamed, Luanda",
        latitude = -8.7690,
        longitude = 13.2450,
        isFavorite = false
    )
    val MUTAMBA = LocationPoint(
        id = "loc_6",
        name = "Largo da Mutamba",
        address = "Baixa de Luanda, Mutamba",
        latitude = -8.8145,
        longitude = 13.2340,
        isFavorite = false
    )
    val MAIANGA = LocationPoint(
        id = "loc_7",
        name = "Largo do Kinaxixi",
        address = "Maianga / Ingombota, Luanda",
        latitude = -8.8180,
        longitude = 13.2405,
        isFavorite = false
    )
    val BENFICA = LocationPoint(
        id = "loc_8",
        name = "Kero Benfica",
        address = "Estrada Principal do Benfica, Luanda",
        latitude = -8.9540,
        longitude = 13.1550,
        isFavorite = false
    )

    val ALL = listOf(MARGINAL, TALATONA, KILAMBA, AEROPORTO, ILHA, MUTAMBA, MAIANGA, BENFICA)
}
