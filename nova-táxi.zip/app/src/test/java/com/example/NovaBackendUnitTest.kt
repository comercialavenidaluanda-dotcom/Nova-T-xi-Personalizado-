package com.example

import com.example.core.network.SupabaseConfig
import com.example.data.model.BackendCommission
import com.example.data.model.DriverProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.RideCategory
import com.example.data.model.RideStatus
import com.example.data.model.UserRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaBackendUnitTest {

    @Test
    fun testSupabaseOfficialProjectTarget() {
        assertEquals("rojyxfjaidyvtmsmefcf", SupabaseConfig.OFFICIAL_PROJECT_REF)
        assertTrue(SupabaseConfig.currentUrl.contains("rojyxfjaidyvtmsmefcf.supabase.co"))
        assertFalse("Should never target NOVA KZ URL", SupabaseConfig.currentUrl.contains("earucsaqqtbllnqsxvlb"))
    }

    @Test
    fun testNovaCommissionCalculation() {
        val fare = 5000L
        val commission = BackendCommission(totalFareAoa = fare)
        assertEquals(20.0, commission.ratePercentage, 0.001)
        assertEquals(1000L, commission.novaAmountAoa) // 20%
        assertEquals(4000L, commission.driverNetAoa)  // 80%
    }

    @Test
    fun testRideStatusFlow() {
        val requested = RideStatus.REQUESTED
        val searching = RideStatus.SEARCHING
        val accepted = RideStatus.ACCEPTED
        val arrived = RideStatus.ARRIVED
        val inProgress = RideStatus.IN_PROGRESS
        val completed = RideStatus.COMPLETED
        val cancelled = RideStatus.CANCELLED

        assertFalse(requested.isFinal)
        assertFalse(searching.isFinal)
        assertFalse(accepted.isFinal)
        assertFalse(arrived.isFinal)
        assertFalse(inProgress.isFinal)
        assertTrue(completed.isFinal)
        assertTrue(cancelled.isFinal)

        assertTrue(accepted.isAcceptedOrBeyond)
        assertTrue(arrived.isAcceptedOrBeyond)
        assertTrue(inProgress.isAcceptedOrBeyond)
        assertTrue(completed.isAcceptedOrBeyond)
        assertFalse(requested.isAcceptedOrBeyond)
    }

    @Test
    fun testRideStatusBackendParsing() {
        assertEquals(RideStatus.REQUESTED, RideStatus.fromBackendString("REQUESTED"))
        assertEquals(RideStatus.SEARCHING, RideStatus.fromBackendString("SEARCHING"))
        assertEquals(RideStatus.ACCEPTED, RideStatus.fromBackendString("ACCEPTED"))
        assertEquals(RideStatus.ACCEPTED, RideStatus.fromBackendString("DISPATCHED"))
        assertEquals(RideStatus.ACCEPTED, RideStatus.fromBackendString("DRIVER_ACCEPTED"))
        assertEquals(RideStatus.ARRIVED, RideStatus.fromBackendString("ARRIVED"))
        assertEquals(RideStatus.IN_PROGRESS, RideStatus.fromBackendString("IN_PROGRESS"))
        assertEquals(RideStatus.COMPLETED, RideStatus.fromBackendString("COMPLETED"))
        assertEquals(RideStatus.CANCELLED, RideStatus.fromBackendString("CANCELLED"))
    }

    @Test
    fun testPaymentMethodProductionFlags() {
        assertTrue("Cash must be production ready", PaymentMethod.CASH.isProductionReady)
        assertFalse("MCX is in homologation", PaymentMethod.MULTICAIXA_EXPRESS.isProductionReady)
        assertFalse("KWiK is in homologation", PaymentMethod.KWIK.isProductionReady)
        assertFalse("IBAN is in homologation", PaymentMethod.IBAN.isProductionReady)
        assertFalse("Referência is in homologation", PaymentMethod.REFERENCIA.isProductionReady)
    }

    @Test
    fun testDriverProfileDefaultsNoMocks() {
        val profile = DriverProfile(
            documentNumber = "001LA2024",
            driverLicenseNumber = "DL-001"
        )
        assertEquals(0L, profile.earningsTodayAoa)
        assertEquals(0, profile.totalRides)
        assertNull(profile.vehicle)
    }
}
