-- ====================================================================
-- NOVA TÁXI — SUPABASE PRODUCTION DATABASE SCHEMA & SECURITY POLICIES
-- Project: NOVA Táxi Angola (Ref: rojyxfjaidyvtmsmefcf)
-- URL: https://rojyxfjaidyvtmsmefcf.supabase.co
-- ====================================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ====================================================================
-- 1. PROFILES (Passageiros e Motoristas)
-- ====================================================================
create table if not exists public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    full_name text not null,
    phone text not null,
    email text,
    role text not null check (role in ('passenger', 'driver', 'admin')),
    rating numeric(3,2) default 5.00 check (rating >= 1.0 and rating <= 5.0),
    avatar_url text,
    created_at timestamptz default now(),
    updated_at timestamptz default now()
);

-- ====================================================================
-- 2. DRIVERS (Perfil de Motorista, Documentação e Estado Operacional)
-- ====================================================================
create table if not exists public.drivers (
    id uuid primary key references public.profiles(id) on delete cascade,
    document_number text not null unique,
    license_number text not null unique,
    is_online boolean default false,
    is_verified boolean default false,
    total_rides integer default 0,
    earnings_today_aoa bigint default 0,
    created_at timestamptz default now(),
    updated_at timestamptz default now()
);

-- ====================================================================
-- 3. VEHICLES (Veículos associados aos motoristas)
-- ====================================================================
create table if not exists public.vehicles (
    id uuid primary key default gen_random_uuid(),
    driver_id uuid not null references public.drivers(id) on delete cascade,
    brand text not null,
    model text not null,
    license_plate text not null unique,
    color text not null,
    year integer not null check (year >= 2000),
    category text not null check (category in ('ECONOMICA', 'COOL', 'EXECUTIVO', 'VIP', 'BIKE')),
    is_active boolean default true,
    created_at timestamptz default now()
);

-- ====================================================================
-- 4. DRIVER_LOCATIONS (Localização GPS em tempo real dos motoristas)
-- ====================================================================
create table if not exists public.driver_locations (
    driver_id uuid primary key references public.drivers(id) on delete cascade,
    latitude double precision not null,
    longitude double precision not null,
    heading real default 0,
    updated_at timestamptz default now()
);

-- ====================================================================
-- 5. RIDE_REQUESTS (Pedidos de Corrida dos Passageiros)
-- ====================================================================
create table if not exists public.ride_requests (
    id text primary key,
    passenger_id uuid not null references public.profiles(id) on delete cascade,
    passenger_name text not null,
    passenger_phone text not null,
    pickup_name text not null,
    pickup_lat double precision not null,
    pickup_lng double precision not null,
    dest_name text not null,
    dest_lat double precision not null,
    dest_lng double precision not null,
    category text not null check (category in ('ECONOMICA', 'COOL', 'EXECUTIVO', 'VIP', 'BIKE')),
    estimated_price_aoa bigint not null check (estimated_price_aoa > 0),
    distance_km numeric(5,2) not null check (distance_km >= 0),
    payment_method text not null check (payment_method in ('CASH', 'MCX', 'REF', 'IBAN', 'KWIK')),
    status text not null default 'REQUESTED' check (status in ('REQUESTED', 'SEARCHING', 'ACCEPTED', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    driver_id uuid references public.drivers(id) on delete set null,
    created_at timestamptz default now(),
    updated_at timestamptz default now()
);

-- ====================================================================
-- 6. RIDES (Contratos de Viagem Confirmados)
-- ====================================================================
create table if not exists public.rides (
    id text primary key,
    request_id text not null references public.ride_requests(id) on delete cascade,
    driver_id uuid not null references public.drivers(id) on delete cascade,
    passenger_id uuid not null references public.profiles(id) on delete cascade,
    status text not null default 'ACCEPTED' check (status in ('ACCEPTED', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    fare_amount_aoa bigint not null check (fare_amount_aoa > 0),
    nova_commission_aoa bigint not null check (nova_commission_aoa >= 0), -- 20%
    driver_net_aoa bigint not null check (driver_net_aoa >= 0),           -- 80%
    payment_method text not null default 'CASH',
    payment_status text not null default 'PENDING' check (payment_status in ('PENDING', 'COMPLETED', 'FAILED')),
    started_at timestamptz default now(),
    completed_at timestamptz
);

-- ====================================================================
-- 7. RIDE_STATUS_HISTORY (Auditoria e rastreio de estados)
-- ====================================================================
create table if not exists public.ride_status_history (
    id uuid primary key default gen_random_uuid(),
    ride_id text not null,
    status text not null,
    changed_by uuid references public.profiles(id),
    changed_at timestamptz default now()
);

-- ====================================================================
-- 8. PAYMENTS (Registo Real de Pagamentos em Dinheiro / Cash)
-- ====================================================================
create table if not exists public.payments (
    id text primary key,
    ride_id text not null references public.rides(id) on delete cascade,
    amount_aoa bigint not null check (amount_aoa > 0),
    method text not null check (method in ('CASH', 'MCX', 'REF', 'IBAN', 'KWIK')),
    status text not null default 'COMPLETED' check (status in ('PENDING', 'COMPLETED', 'REFUNDED')),
    recorded_at timestamptz default now()
);

-- ====================================================================
-- 9. COMMISSIONS (Auditoria de Comissões NOVA - 20%)
-- ====================================================================
create table if not exists public.commissions (
    id uuid primary key default gen_random_uuid(),
    ride_id text not null references public.rides(id) on delete cascade,
    total_fare_aoa bigint not null,
    nova_rate numeric(4,2) default 0.20,
    nova_amount_aoa bigint not null,
    driver_amount_aoa bigint not null,
    created_at timestamptz default now()
);

-- ====================================================================
-- 10. RATINGS (Avaliações mútuas Passageiro <-> Motorista)
-- ====================================================================
create table if not exists public.ratings (
    id text primary key,
    ride_id text not null references public.rides(id) on delete cascade,
    from_user_id uuid not null references public.profiles(id) on delete cascade,
    to_user_id uuid not null references public.profiles(id) on delete cascade,
    score integer not null check (score >= 1 and score <= 5),
    comment text,
    created_at timestamptz default now()
);

-- ====================================================================
-- 11. NOTIFICATIONS
-- ====================================================================
create table if not exists public.notifications (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references public.profiles(id) on delete cascade,
    title text not null,
    body text not null,
    is_read boolean default false,
    created_at timestamptz default now()
);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================
alter table public.profiles enable row level security;
alter table public.drivers enable row level security;
alter table public.vehicles enable row level security;
alter table public.driver_locations enable row level security;
alter table public.ride_requests enable row level security;
alter table public.rides enable row level security;
alter table public.ride_status_history enable row level security;
alter table public.payments enable row level security;
alter table public.commissions enable row level security;
alter table public.ratings enable row level security;
alter table public.notifications enable row level security;

-- Profiles: Qualquer utilizador autenticado pode ler perfis; apenas o proprietário pode editar
create policy "Allow read profiles" on public.profiles for select using (true);
create policy "Allow insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Allow update own profile" on public.profiles for update using (auth.uid() = id);

-- Drivers: Leitura pública para ver motoristas online; update próprio
create policy "Allow read drivers" on public.drivers for select using (true);
create policy "Allow insert driver profile" on public.drivers for insert with check (auth.uid() = id);
create policy "Allow update driver profile" on public.drivers for update using (auth.uid() = id);

-- Vehicles: Leitura pública; gestão pelo motorista proprietário
create policy "Allow read vehicles" on public.vehicles for select using (true);
create policy "Allow manage own vehicle" on public.vehicles for all using (auth.uid() = driver_id);

-- Driver Locations: Leitura aberta para mapa; update apenas pelo próprio motorista
create policy "Allow read driver locations" on public.driver_locations for select using (true);
create policy "Allow update own driver location" on public.driver_locations for all using (auth.uid() = driver_id);

-- Ride Requests: Passageiro cria e gere; motoristas online podem consultar pedidos REQUESTED
create policy "Allow read ride requests" on public.ride_requests for select using (
    auth.uid() = passenger_id or auth.uid() = driver_id or status = 'REQUESTED'
);
create policy "Allow insert own ride request" on public.ride_requests for insert with check (
    auth.uid() = passenger_id
);
create policy "Allow update ride request" on public.ride_requests for update using (
    auth.uid() = passenger_id or auth.uid() = driver_id or status = 'REQUESTED'
);

-- Rides: Visíveis para passageiro e motorista da corrida
create policy "Allow read participant rides" on public.rides for select using (
    auth.uid() = passenger_id or auth.uid() = driver_id
);
create policy "Allow insert ride" on public.rides for insert with check (
    auth.uid() = driver_id or auth.uid() = passenger_id
);
create policy "Allow update ride" on public.rides for update using (
    auth.uid() = driver_id or auth.uid() = passenger_id
);

-- Payments: Visíveis para passageiro e motorista
create policy "Allow read payments" on public.payments for select using (true);
create policy "Allow insert payment" on public.payments for insert with check (true);

-- Commissions: Visíveis para motorista e sistema
create policy "Allow read commissions" on public.commissions for select using (true);

-- Ratings: Leitura pública; inserção pelo autor autenticado
create policy "Allow read ratings" on public.ratings for select using (true);
create policy "Allow insert rating" on public.ratings for insert with check (auth.uid() = from_user_id);

-- ====================================================================
-- BACKEND RPC FUNCTIONS (Idempotência, Comissão 20% e Segurança)
-- ====================================================================

-- 1. Cálculo de Tarifa e Comissão 20% no Backend
create or replace function public.nova_calculate_fare_and_commission(
    p_category text,
    p_distance_km numeric
)
returns jsonb
language plpgsql
security definer
as $$
declare
    v_base_price bigint;
    v_km_rate bigint;
    v_fare bigint;
    v_commission bigint;
    v_driver_net bigint;
begin
    case p_category
        when 'ECONOMICA' then
            v_base_price := 1200;
            v_km_rate := 110;
        when 'COOL' then
            v_base_price := 1500;
            v_km_rate := 150;
        when 'EXECUTIVO' then
            v_base_price := 3000;
            v_km_rate := 250;
        when 'VIP' then
            v_base_price := 5000;
            v_km_rate := 350;
        when 'BIKE' then
            v_base_price := 800;
            v_km_rate := 90;
        else
            v_base_price := 1500;
            v_km_rate := 150;
    end case;

    v_fare := v_base_price + round(p_distance_km * v_km_rate);
    v_commission := round(v_fare * 0.20);
    v_driver_net := v_fare - v_commission;

    return jsonb_build_object(
        'category', p_category,
        'distance_km', p_distance_km,
        'fare_amount_aoa', v_fare,
        'nova_commission_aoa', v_commission,
        'driver_net_aoa', v_driver_net,
        'commission_rate', 0.20
    );
end;
$$;

-- 2. Aceitação Atómica de Corrida (Proteção contra dupla aceitação)
create or replace function public.nova_accept_ride(
    p_request_id text,
    p_driver_id uuid
)
returns jsonb
language plpgsql
security definer
as $$
declare
    v_req record;
    v_ride_id text;
    v_commission bigint;
    v_driver_net bigint;
begin
    -- Bloqueio exclusivo de linha (concurrency lock)
    select * into v_req
    from public.ride_requests
    where id = p_request_id and status in ('REQUESTED', 'SEARCHING')
    for update;

    if not found then
        raise exception 'Esta corrida já foi aceite por outro motorista ou foi cancelada.';
    end if;

    -- Calcular comissão 20%
    v_commission := round(v_req.estimated_price_aoa * 0.20);
    v_driver_net := v_req.estimated_price_aoa - v_commission;
    v_ride_id := 'ride_' || substr(md5(random()::text || clock_timestamp()::text), 1, 12);

    -- Atualizar ride_requests
    update public.ride_requests
    set status = 'ACCEPTED',
        driver_id = p_driver_id,
        updated_at = now()
    where id = p_request_id;

    -- Criar contrato em rides
    insert into public.rides (
        id, request_id, driver_id, passenger_id, status,
        fare_amount_aoa, nova_commission_aoa, driver_net_aoa,
        payment_method, payment_status, started_at
    ) values (
        v_ride_id, p_request_id, p_driver_id, v_req.passenger_id, 'ACCEPTED',
        v_req.estimated_price_aoa, v_commission, v_driver_net,
        v_req.payment_method, 'PENDING', now()
    );

    -- Registar comissão
    insert into public.commissions (ride_id, total_fare_aoa, nova_rate, nova_amount_aoa, driver_amount_aoa)
    values (v_ride_id, v_req.estimated_price_aoa, 0.20, v_commission, v_driver_net);

    -- Registar histórico de estado
    insert into public.ride_status_history (ride_id, status, changed_by)
    values (v_ride_id, 'ACCEPTED', p_driver_id);

    return jsonb_build_object(
        'success', true,
        'ride_id', v_ride_id,
        'request_id', p_request_id,
        'status', 'ACCEPTED',
        'fare_amount_aoa', v_req.estimated_price_aoa,
        'nova_commission_aoa', v_commission,
        'driver_net_aoa', v_driver_net
    );
end;
$$;

-- 3. Atualizar Estado da Corrida e Histórico
create or replace function public.nova_update_ride_status(
    p_ride_id text,
    p_status text,
    p_user_id uuid
)
returns jsonb
language plpgsql
security definer
as $$
declare
    v_ride record;
begin
    update public.rides
    set status = p_status,
        completed_at = case when p_status = 'COMPLETED' then now() else completed_at end
    where id = p_ride_id or request_id = p_ride_id
    returning * into v_ride;

    if not found then
        -- Tentar atualizar em ride_requests se for o id do pedido
        update public.ride_requests
        set status = p_status,
            updated_at = now()
        where id = p_ride_id;
    else
        update public.ride_requests
        set status = p_status,
            updated_at = now()
        where id = v_ride.request_id;
    end if;

    -- Registar no histórico
    insert into public.ride_status_history (ride_id, status, changed_by)
    values (p_ride_id, p_status, p_user_id);

    return jsonb_build_object('success', true, 'ride_id', p_ride_id, 'status', p_status);
end;
$$;

-- 4. Registar Pagamento em Cash Real
create or replace function public.nova_record_cash_payment(
    p_ride_id text,
    p_amount_aoa bigint
)
returns jsonb
language plpgsql
security definer
as $$
declare
    v_payment_id text;
begin
    v_payment_id := 'pay_' || substr(md5(random()::text || clock_timestamp()::text), 1, 10);

    insert into public.payments (id, ride_id, amount_aoa, method, status)
    values (v_payment_id, p_ride_id, p_amount_aoa, 'CASH', 'COMPLETED');

    update public.rides
    set payment_status = 'COMPLETED'
    where id = p_ride_id or request_id = p_ride_id;

    -- Atualizar ganhos do motorista
    update public.drivers
    set total_rides = total_rides + 1,
        earnings_today_aoa = earnings_today_aoa + round(p_amount_aoa * 0.80),
        updated_at = now()
    where id = (select driver_id from public.rides where id = p_ride_id or request_id = p_ride_id limit 1);

    return jsonb_build_object('success', true, 'payment_id', v_payment_id, 'status', 'COMPLETED');
end;
$$;
